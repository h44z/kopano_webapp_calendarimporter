<?php
// config options
$ADMINUSERNAME = "admin";                   // Kopano administrative user
$ADMINPASSWORD = "admin";                   // Kopano administrative user password
$SERVER = "http://localhost:236/kopano";         // Kopano socket or http(s) connection
$CALDAVURL = "http://localhost:8080/ical/"; // Caldav URL
$TEMPDIR = "/tmp/";                         // Temporary directory for storing downloaded ics files
