/**
 * ABOUT.js, Kopano calender to ics im/exporter
 *
 * Author: Christoph Haas <christoph.h@sprinternet.at>
 * Copyright (C) 2012-2018 Christoph Haas
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

Ext.namespace('Zarafa.plugins.calendarimporter');

/**
 * @class Zarafa.plugins.calendarimporter.ABOUT
 * @extends String
 *
 * The copyright string holding the copyright notice for the Zarafa calendarimporter Plugin.
 */
Zarafa.plugins.calendarimporter.ABOUT = ""
    + "<p>Copyright (C) 2012-2018  Christoph Haas &lt;christoph.h@sprinternet.at&gt;</p>"

    + "<p>This program is free software; you can redistribute it and/or "
    + "modify it under the terms of the GNU Lesser General Public "
    + "License as published by the Free Software Foundation; either "
    + "version 2.1 of the License, or (at your option) any later version.</p>"

    + "<p>This program is distributed in the hope that it will be useful, "
    + "but WITHOUT ANY WARRANTY; without even the implied warranty of "
    + "MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU "
    + "Lesser General Public License for more details.</p>"

    + "<p>You should have received a copy of the GNU Lesser General Public "
    + "License along with this program; if not, write to the Free Software "
    + "Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA</p>"

    + "<hr />"

    + "<p>The calendarimporter plugin contains the following third-party components:</p>"

    + "<h1>sabre-io/vobject v4.1</h1>"

    + "<p>Copyright (C) 2011-2016 fruux GmbH (https://fruux.com/)</p>"
    
    + "<p>Licensed under the BSD 3-Clause \"New\" or \"Revised\" License</p>";/**
 * Actions.js zarafa calender to ics im/exporter
 *
 * Author: Christoph Haas <christoph.h@sprinternet.at>
 * Copyright (C) 2012-2018 Christoph Haas
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

/**
 * ResponseHandler
 *
 * This class handles all responses from the php backend
 */
Ext.namespace('Zarafa.plugins.calendarimporter.data');

/**
 * @class Zarafa.plugins.calendarimporter.data.Actions
 * Common actions which can be used within {@link Ext.Button buttons}
 * or other {@link Ext.Component components} with action handlers.
 * @singleton
 */
Zarafa.plugins.calendarimporter.data.Actions = {
    /**
     * Generates a request to download the selected records as vCard.
     *
     * @param storeId
     * @param recordIds
     */
    exportToICS: function (storeId, recordIds, recordFolder) {
        if ((typeof recordIds != "undefined" && recordIds.length < 1) || (typeof recordFolder != "undefined" && recordFolder.get('content_count') < 1)) {
            Zarafa.common.dialogs.MessageBox.show({
                title: dgettext('plugin_calendarimporter', 'Error'),
                msg: dgettext('plugin_calendarimporter', 'No events found. Export skipped!'),
                icon: Zarafa.common.dialogs.MessageBox.ERROR,
                buttons: Zarafa.common.dialogs.MessageBox.OK
            });
        } else {

            var responseHandler = new Zarafa.plugins.calendarimporter.data.ResponseHandler({
                successCallback: Zarafa.plugins.calendarimporter.data.Actions.downloadICS
            });

            var recordcount = 0;
            var exportPayload = {
                storeid: storeId,
                records: undefined,
                folder: undefined
            };

            if (typeof recordIds != "undefined") {
                exportPayload.records = recordIds;
                recordcount = recordIds.length;
            }

            if (typeof recordFolder != "undefined") {
                exportPayload.folder = recordFolder.get("entryid");
                recordcount = recordFolder.get('content_count');
            }

            // Notify user
            // # TRANSLATORS: {0} will be replaced by the number of contacts that will be exported
            container.getNotifier().notify('info', dgettext('plugin_contactimporter', 'Calendar Export'), String.format(dgettext('plugin_calendarimporter', 'Exporting {0} events. Please wait...'), recordcount));


            // request attachment preperation
            container.getRequest().singleRequest(
                'calendarmodule',
                'export',
                exportPayload,
                responseHandler
            );
        }
    },

    /**
     * Callback for the export request.
     * @param {Object} response
     */
    downloadICS: function (response) {
        if (response.status == false) {
            Zarafa.common.dialogs.MessageBox.show({
                title: dgettext('plugin_calendarimporter', 'Warning'),
                msg: response.message,
                icon: Zarafa.common.dialogs.MessageBox.WARNING,
                buttons: Zarafa.common.dialogs.MessageBox.OK
            });
        } else {
            var downloadFrame = Ext.getBody().createChild({
                tag: 'iframe',
                cls: 'x-hidden'
            });

            var url = document.URL;
            var link = url.substring(0, url.lastIndexOf('/') + 1);

            link += "index.php?sessionid=" + container.getUser().getSessionId() + "&load=custom&name=download_ics";
            link = Ext.urlAppend(link, "token=" + encodeURIComponent(response.download_token));
            link = Ext.urlAppend(link, "filename=" + encodeURIComponent(response.filename));

            downloadFrame.dom.contentWindow.location = link;
        }
    },

    /**
     * Get all calendar folders.
     * @param {boolean} asDropdownStore If true, a simple array store will be returned.
     * @returns {*}
     */
    getAllCalendarFolders: function (asDropdownStore) {
        asDropdownStore = Ext.isEmpty(asDropdownStore) ? false : asDropdownStore;

        var allFolders = [];

        var inbox = container.getHierarchyStore().getDefaultStore();
        var pub = container.getHierarchyStore().getPublicStore();

        if (!Ext.isEmpty(inbox.subStores) && inbox.subStores.folders.totalLength > 0) {
            for (var i = 0; i < inbox.subStores.folders.totalLength; i++) {
                var folder = inbox.subStores.folders.getAt(i);
                if (!Ext.isEmpty(folder) && folder.get("container_class") == "IPF.Appointment") {
                    if (asDropdownStore) {
                        allFolders.push([
                            folder.get("entryid"),
                            folder.get("display_name")
                        ]);
                    } else {
                        allFolders.push({
                            display_name: folder.get("display_name"),
                            entryid: folder.get("entryid"),
                            store_entryid: folder.get("store_entryid"),
                            is_public: false
                        });
                    }
                }
            }
        }

        if (!Ext.isEmpty(pub.subStores) && pub.subStores.folders.totalLength > 0) {
            for (var j = 0; j < pub.subStores.folders.totalLength; j++) {
                var folder = pub.subStores.folders.getAt(j);
                if (!Ext.isEmpty(folder) && folder.get("container_class") == "IPF.Appointment") {
                    if (asDropdownStore) {
                        allFolders.push([
                            folder.get("entryid"),
                            folder.get("display_name") + " (Public)"
                        ]);
                    } else {
                        allFolders.push({
                            display_name: folder.get("display_name"),
                            entryid: folder.get("entryid"),
                            store_entryid: folder.get("store_entryid"),
                            is_public: true
                        });
                    }
                }
            }
        }

        if (asDropdownStore) {
            return allFolders.sort(Zarafa.plugins.calendarimporter.data.Actions.dynamicSort(1));
        } else {
            return allFolders;
        }
    },

    /**
     * Return a calendar folder element by name.
     * @param {string} name
     * @returns {*}
     */
    getCalendarFolderByName: function (name) {
        var folders = Zarafa.plugins.calendarimporter.data.Actions.getAllCalendarFolders(false);

        for (var i = 0; i < folders.length; i++) {
            if (folders[i].display_name == name) {
                return folders[i];
            }
        }

        return container.getHierarchyStore().getDefaultFolder('calendar');
    },

    /**
     * Return a calendar folder element by entryid.
     * @param {string} entryid
     * @returns {*}
     */
    getCalendarFolderByEntryid: function (entryid) {
        var folders = Zarafa.plugins.calendarimporter.data.Actions.getAllCalendarFolders(false);

        for (var i = 0; i < folders.length; i++) {
            if (folders[i].entryid == entryid) {
                return folders[i];
            }
        }

        return container.getHierarchyStore().getDefaultFolder('calendar');
    },

    /**
     * Dynamic sort function, sorts by property name.
     * @param {string|int} property
     * @returns {Function}
     */
    dynamicSort: function (property) {
        var sortOrder = 1;
        if (property[0] === "-") {
            sortOrder = -1;
            property = property.substr(1);
        }
        return function (a, b) {
            var result = (a[property].toLowerCase() < b[property].toLowerCase()) ? -1 : (a[property].toLowerCase() > b[property].toLowerCase()) ? 1 : 0;
            return result * sortOrder;
        }
    }
};
/**
 * ResponseHandler.js, Kopano calender to ics im/exporter
 *
 * Author: Christoph Haas <christoph.h@sprinternet.at>
 * Copyright (C) 2012-2018 Christoph Haas
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

/**
 * ResponseHandler
 *
 * This class handles all responses from the php backend
 */
Ext.namespace('Zarafa.plugins.calendarimporter.data');

/**
 * @class Zarafa.plugins.calendarimporter.data.ResponseHandler
 * @extends Zarafa.plugins.calendarimporter.data.AbstractResponseHandler
 *
 * Calendar specific response handler.
 */
Zarafa.plugins.calendarimporter.data.ResponseHandler = Ext.extend(Zarafa.core.data.AbstractResponseHandler, {
    /**
     * @cfg {Function} successCallback The function which
     * will be called after success request.
     */
    successCallback: null,

    /**
     * Call the successCallback callback function.
     * @param {Object} response Object contained the response data.
     */
    doExport: function (response) {
        this.successCallback(response);
    },

    /**
     * Call the successCallback callback function.
     * @param {Object} response Object contained the response data.
     */
    doLoad: function (response) {
        this.successCallback(response);
    },

    /**
     * Call the successCallback callback function.
     * @param {Object} response Object contained the response data.
     */
    doImport: function (response) {
        this.successCallback(response);
    },

    /**
     * Call the successCallback callback function.
     * @param {Object} response Object contained the response data.
     */
    doImportattachment: function (response) {
        this.successCallback(response);
    },

    /**
     * In case exception happened on server, server will return
     * exception response with the code of exception.
     * @param {Object} response Object contained the response data.
     */
    doError: function (response) {
        alert("error response code: " + response.error.info.code);
    }
});

Ext.reg('calendarimporter.calendarresponsehandler', Zarafa.plugins.calendarimporter.data.ResponseHandler);/**
 * timezones.js, Kopano calender to ics im/exporter
 *
 * Author: Christoph Haas <christoph.h@sprinternet.at>
 * Copyright (C) 2012-2018 Christoph Haas
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

/**
 * Timezone class
 *
 * This class can handle all our timezone operations and conversions.
 */
Ext.namespace("Zarafa.plugins.calendarimporter.data");

Zarafa.plugins.calendarimporter.data.Timezones = Ext.extend(Object, {

    store: [
        ['Pacific/Midway', '(UTC -11:00) Midway, Niue, Pago Pago', -660],
        ['Pacific/Fakaofo', '(UTC -10:00) Adak, Fakaofo, Honolulu, Johnston, Rarotonga, Tahiti', -600],
        ['Pacific/Marquesas', '(UTC -09:30) Marquesas', -570],
        ['America/Anchorage', '(UTC -09:00) Gambier, Anchorage, Juneau, Nome, Sitka, Yakutat', -540],
        ['America/Dawson', '(UTC -08:00) Dawson, Los Angeles, Tijuana, Vancouver, Whitehorse, Santa Isabel, Metlakatla, Pitcairn', -480],
        ['America/Dawson_Creek', '(UTC -07:00) Dawson Creek, Hermosillo, Phoenix, Chihuahua, Mazatlan, Boise, Cambridge Bay, Denver, Edmonton, Inuvik, Ojinaga, Shiprock, Yellowknife', -420],
        ['America/Chicago', '(UTC -06:00) Beulah, Center, Chicago, Knox, Matamoros, Menominee, New Salem, Rainy River, Rankin Inlet, Resolute, Tell City, Winnipeg', -360],
        ['America/Belize', '(UTC -06:00) Belize, Costa Rica, El Salvador, Galapagos, Guatemala, Managua, Regina, Swift Current, Tegucigalpa', -360],
        ['Pacific/Easter', '(UTC -06:00) Easter', -360],
        ['America/Bahia_Banderas', '(UTC -06:00) Bahia Banderas, Cancun, Merida, Mexico City, Monterrey', -360],
        ['America/Detroit', '(UTC -05:00) Detroit, Grand Turk, Indianapolis, Iqaluit, Louisville, Marengo, Monticello, Montreal, Nassau, New York, Nipigon, Pangnirtung, Petersburg, Thunder Bay, Toronto, Vevay, Vincennes, Winamac', -300],
        ['America/Atikokan', '(UTC -05:00) Atikokan, Bogota, Cayman, Guayaquil, Jamaica, Lima, Panama, Port-au-Prince', -300],
        ['America/Havana', '(UTC -05:00) Havana', -300],
        ['America/Caracas', '(UTC -04:30) Caracas', -270],
        ['America/Glace_Bay', '(UTC -04:00) Bermuda, Glace Bay, Goose Bay, Halifax, Moncton, Thule', -240],
        ['Atlantic/Stanley', '(UTC -04:00) Stanley', -240],
        ['America/Santiago', '(UTC -04:00) Palmer, Santiago', -240],
        ['America/Anguilla', '(UTC -04:00) Anguilla, Antigua, Aruba, Barbados, Blanc-Sablon, Boa Vista, Curacao, Dominica, Eirunepe, Grenada, Guadeloupe, Guyana, Kralendijk, La Paz, Lower Princes, Manaus, Marigot, Martinique, Montserrat, Port of Spain, Porto Velho, Puerto Rico, Rio Branco, Santo Domingo, St Barthelemy, St Kitts, St Lucia, St Thomas, St Vincent, Tortola', -240],
        ['America/Campo_Grande', '(UTC -04:00) Campo Grande, Cuiaba', -240],
        ['America/Asuncion', '(UTC -04:00) Asuncion', -240],
        ['America/St_Johns', '(UTC -03:30) St Johns', -210],
        ['America/Sao_Paulo', '(UTC -03:00) Sao Paulo', -180],
        ['America/Araguaina', '(UTC -03:00) Araguaina, Bahia, Belem, Buenos Aires, Catamarca, Cayenne, Cordoba, Fortaleza, Jujuy, La Rioja, Maceio, Mendoza, Paramaribo, Recife, Rio Gallegos, Rothera, Salta, San Juan, Santarem, Tucuman, Ushuaia', -180],
        ['America/Montevideo', '(UTC -03:00) Montevideo', -180],
        ['America/Godthab', '(UTC -03:00) Godthab', -180],
        ['America/Argentina/San_Luis', '(UTC -03:00) San Luis', -180],
        ['America/Miquelon', '(UTC -03:00) Miquelon', -180],
        ['America/Noronha', '(UTC -02:00) Noronha, South Georgia', -120],
        ['Atlantic/Cape_Verde', '(UTC -01:00) Cape Verde', -60],
        ['America/Scoresbysund', '(UTC -01:00) Azores, Scoresbysund', -60],
        ['Atlantic/Canary', '(UTC) Canary, Dublin, Faroe, Guernsey, Isle of Man, Jersey, Lisbon, London, Madeira', 0],
        ['Africa/Abidjan', '(UTC) Abidjan, Accra, Bamako, Banjul, Bissau, Casablanca, Conakry, Dakar, Danmarkshavn, El Aaiun, Freetown, Lome, Monrovia, Nouakchott, Ouagadougou, Reykjavik, Sao Tome, St Helena', 0],
        ['Africa/Algiers', '(UTC +01:00) Algiers, Bangui, Brazzaville, Douala, Kinshasa, Lagos, Libreville, Luanda, Malabo, Ndjamena, Niamey, Porto-Novo, Tunis', 60],
        ['Europe/Vienna', '(UTC +01:00) Amsterdam, Andorra, Belgrade, Berlin, Bratislava, Brussels, Budapest, Ceuta, Copenhagen, Gibraltar, Ljubljana, Longyearbyen, Luxembourg, Madrid, Malta, Monaco, Oslo, Paris, Podgorica, Prague, Rome, San Marino, Sarajevo, Skopje, Stockholm, Tirane, Vaduz, Vatican, Vienna, Warsaw, Zagreb, Zurich', 60],
        ['Africa/Windhoek', '(UTC +01:00) Windhoek', 60],
        ['Asia/Damascus', '(UTC +02:00) Damascus', 120],
        ['Asia/Beirut', '(UTC +02:00) Beirut', 120],
        ['Asia/Jerusalem', '(UTC +02:00) Jerusalem', 120],
        ['Asia/Nicosia', '(UTC +02:00) Athens, Bucharest, Chisinau, Helsinki, Istanbul, Mariehamn, Nicosia, Riga, Sofia, Tallinn, Vilnius', 120],
        ['Africa/Blantyre', '(UTC +02:00) Blantyre, Bujumbura, Cairo, Gaborone, Gaza, Harare, Hebron, Johannesburg, Kigali, Lubumbashi, Lusaka, Maputo, Maseru, Mbabane, Tripoli', 120],
        ['Asia/Amman', '(UTC +02:00) Amman', 120],
        ['Africa/Addis_Ababa', '(UTC +03:00) Addis Ababa, Aden, Antananarivo, Asmara, Baghdad, Bahrain, Comoro, Dar es Salaam, Djibouti, Juba, Kaliningrad, Kampala, Khartoum, Kiev, Kuwait, Mayotte, Minsk, Mogadishu, Nairobi, Qatar, Riyadh, Simferopol, Syowa, Uzhgorod, Zaporozhye', 180],
        ['Asia/Tehran', '(UTC +03:30) Tehran', 210],
        ['Asia/Yerevan', '(UTC +04:00) Yerevan', 240],
        ['Asia/Dubai', '(UTC +04:00) Dubai, Mahe, Mauritius, Moscow, Muscat, Reunion, Samara, Tbilisi, Volgograd', 240],
        ['Asia/Baku', '(UTC +04:00) Baku', 240],
        ['Asia/Kabul', '(UTC +04:30) Kabul', 270],
        ['Antarctica/Mawson', '(UTC +05:00) Aqtau, Aqtobe, Ashgabat, Dushanbe, Karachi, Kerguelen, Maldives, Mawson, Oral, Samarkand, Tashkent', 300],
        ['Asia/Colombo', '(UTC +05:30) Colombo, Kolkata', 330],
        ['Asia/Kathmandu', '(UTC +05:45) Kathmandu', 345],
        ['Antarctica/Vostok', '(UTC +06:00) Almaty, Bishkek, Chagos, Dhaka, Qyzylorda, Thimphu, Vostok, Yekaterinburg', 360],
        ['Asia/Rangoon', '(UTC +06:30) Cocos, Rangoon', 390],
        ['Antarctica/Davis', '(UTC +07:00) Bangkok, Christmas, Davis, Ho Chi Minh, Hovd, Jakarta, Novokuznetsk, Novosibirsk, Omsk, Phnom Penh, Pontianak, Vientiane', 420],
        ['Antarctica/Casey', '(UTC +08:00) Brunei, Casey, Choibalsan, Chongqing, Harbin, Hong Kong, Kashgar, Krasnoyarsk, Kuala Lumpur, Kuching, Macau, Makassar, Manila, Perth, Shanghai, Singapore, Taipei, Ulaanbaatar, Urumqi', 480],
        ['Australia/Eucla', '(UTC +08:45) Eucla', 525],
        ['Asia/Dili', '(UTC +09:00) Dili, Irkutsk, Jayapura, Palau, Pyongyang, Seoul, Tokyo', 540],
        ['Australia/Adelaide', '(UTC +09:30) Adelaide, Broken Hill', 570],
        ['Australia/Darwin', '(UTC +09:30) Darwin', 570],
        ['Antarctica/DumontDUrville', '(UTC +10:00) Brisbane, Chuuk, DumontDUrville, Guam, Lindeman, Port Moresby, Saipan, Yakutsk', 600],
        ['Australia/Currie', '(UTC +10:00) Currie, Hobart, Melbourne, Sydney', 600],
        ['Australia/Lord_Howe', '(UTC +10:30) Lord Howe', 630],
        ['Antarctica/Macquarie', '(UTC +11:00) Efate, Guadalcanal, Kosrae, Macquarie, Noumea, Pohnpei, Sakhalin, Vladivostok', 660],
        ['Pacific/Norfolk', '(UTC +11:30) Norfolk', 690],
        ['Antarctica/McMurdo', '(UTC +12:00) Auckland, McMurdo, South Pole', 720],
        ['Asia/Anadyr', '(UTC +12:00) Anadyr, Fiji, Funafuti, Kamchatka, Kwajalein, Magadan, Majuro, Nauru, Tarawa, Wake, Wallis', 720],
        ['Pacific/Chatham', '(UTC +12:45) Chatham', 765],
        ['Pacific/Enderbury', '(UTC +13:00) Enderbury, Tongatapu', 780],
        ['Pacific/Apia', '(UTC +13:00) Apia', 780],
        ['Pacific/Kiritimati', '(UTC +14:00) Kiritimati', 840]
    ],

    /* map all citys to the above timezones */
    map: {
        /*-11:00*/
        'Etc/GMT+11': 'Pacific/Midway',
        'Pacific/Midway': 'Pacific/Midway',
        'Pacific/Niue': 'Pacific/Midway',
        'Pacific/Pago_Pago': 'Pacific/Midway',
        'Pacific/Samoa': 'Pacific/Midway',
        'US/Samoa': 'Pacific/Midway',
        /*-10:00*/
        'America/Adak': 'Pacific/Fakaofo',
        'America/Atka': 'Pacific/Fakaofo',
        'Etc/GMT+10': 'Pacific/Fakaofo',
        'HST': 'Pacific/Fakaofo',
        'Pacific/Honolulu': 'Pacific/Fakaofo',
        'Pacific/Johnston': 'Pacific/Fakaofo',
        'Pacific/Rarotonga': 'Pacific/Fakaofo',
        'Pacific/Tahiti': 'Pacific/Fakaofo',
        'SystemV/HST10': 'Pacific/Fakaofo',
        'US/Aleutian': 'Pacific/Fakaofo',
        'US/Hawaii': 'Pacific/Fakaofo',
        /*-9:30*/
        'Pacific/Marquesas': 'Pacific/Marquesas',
        /*-9:00*/
        'AST': 'America/Anchorage',
        'America/Anchorage': 'America/Anchorage',
        'America/Juneau': 'America/Anchorage',
        'America/Nome': 'America/Anchorage',
        'America/Sitka': 'America/Anchorage',
        'America/Yakutat': 'America/Anchorage',
        'Etc/GMT+9': 'America/Anchorage',
        'Pacific/Gambier': 'America/Anchorage',
        'SystemV/YST9': 'America/Anchorage',
        'SystemV/YST9YDT': 'America/Anchorage',
        'US/Alaska': 'America/Anchorage',
        /*-8:00*/
        'America/Dawson': 'America/Dawson',
        'America/Ensenada': 'America/Dawson',
        'America/Los_Angeles': 'America/Dawson',
        'America/Metlakatla': 'America/Dawson',
        'America/Santa_Isabel': 'America/Dawson',
        'America/Tijuana': 'America/Dawson',
        'America/Vancouver': 'America/Dawson',
        'America/Whitehorse': 'America/Dawson',
        'Canada/Pacific': 'America/Dawson',
        'Canada/Yukon': 'America/Dawson',
        'Etc/GMT+8': 'America/Dawson',
        'Mexico/BajaNorte': 'America/Dawson',
        'PST': 'America/Dawson',
        'PST8PDT': 'America/Dawson',
        'Pacific/Pitcairn': 'America/Dawson',
        'SystemV/PST8': 'America/Dawson',
        'SystemV/PST8PDT': 'America/Dawson',
        'US/Pacific': 'America/Dawson',
        'US/Pacific-New': 'America/Dawson',
        /*-7:00*/
        'America/Boise': 'America/Dawson_Creek',
        'America/Cambridge_Bay': 'America/Dawson_Creek',
        'America/Chihuahua': 'America/Dawson_Creek',
        'America/Creston': 'America/Dawson_Creek',
        'America/Dawson_Creek': 'America/Dawson_Creek',
        'America/Denver': 'America/Dawson_Creek',
        'America/Edmonton': 'America/Dawson_Creek',
        'America/Hermosillo': 'America/Dawson_Creek',
        'America/Inuvik': 'America/Dawson_Creek',
        'America/Mazatlan': 'America/Dawson_Creek',
        'America/Ojinaga': 'America/Dawson_Creek',
        'America/Phoenix': 'America/Dawson_Creek',
        'America/Shiprock': 'America/Dawson_Creek',
        'America/Yellowknife': 'America/Dawson_Creek',
        'Canada/Mountain': 'America/Dawson_Creek',
        'Etc/GMT+7': 'America/Dawson_Creek',
        'MST': 'America/Dawson_Creek',
        'MST7MDT': 'America/Dawson_Creek',
        'Mexico/BajaSur': 'America/Dawson_Creek',
        'Navajo': 'America/Dawson_Creek',
        'PNT': 'America/Dawson_Creek',
        'SystemV/MST7': 'America/Dawson_Creek',
        'SystemV/MST7MDT': 'America/Dawson_Creek',
        'US/Arizona': 'America/Dawson_Creek',
        'US/Mountain': 'America/Dawson_Creek',
        /*-6:00*/
        'America/Bahia_Banderas': 'America/Chicago',
        'America/Belize': 'America/Chicago',
        'America/Cancun': 'America/Chicago',
        'America/Chicago': 'America/Chicago',
        'America/Costa_Rica': 'America/Chicago',
        'America/El_Salvador': 'America/Chicago',
        'America/Guatemala': 'America/Chicago',
        'America/Indiana/Knox': 'America/Chicago',
        'America/Indiana/Tell_City': 'America/Chicago',
        'America/Knox_IN': 'America/Chicago',
        'America/Managua': 'America/Chicago',
        'America/Matamoros': 'America/Chicago',
        'America/Menominee': 'America/Chicago',
        'America/Merida': 'America/Chicago',
        'America/Mexico_City': 'America/Chicago',
        'America/Monterrey': 'America/Chicago',
        'America/North_Dakota/Beulah': 'America/Chicago',
        'America/North_Dakota/Center': 'America/Chicago',
        'America/North_Dakota/New_Salem': 'America/Chicago',
        'America/Rainy_River': 'America/Chicago',
        'America/Rankin_Inlet': 'America/Chicago',
        'America/Regina': 'America/Chicago',
        'America/Resolute': 'America/Chicago',
        'America/Swift_Current': 'America/Chicago',
        'America/Tegucigalpa': 'America/Chicago',
        'America/Winnipeg': 'America/Chicago',
        'CST': 'America/Chicago',
        'CST6CDT': 'America/Chicago',
        'Canada/Central': 'America/Chicago',
        'Canada/East-Saskatchewan': 'America/Chicago',
        'Canada/Saskatchewan': 'America/Chicago',
        'Chile/EasterIsland': 'America/Chicago',
        'Etc/GMT+6': 'America/Chicago',
        'Mexico/General': 'America/Chicago',
        'Pacific/Easter': 'America/Chicago',
        'Pacific/Galapagos': 'America/Chicago',
        'SystemV/CST6': 'America/Chicago',
        'SystemV/CST6CDT': 'America/Chicago',
        'US/Central': 'America/Chicago',
        'US/Indiana-Starke': 'America/Chicago',
        /*-5:00*/
        'America/Atikokan': 'America/Detroit',
        'America/Bogota': 'America/Detroit',
        'America/Cayman': 'America/Detroit',
        'America/Coral_Harbour': 'America/Detroit',
        'America/Detroit': 'America/Detroit',
        'America/Fort_Wayne': 'America/Detroit',
        'America/Grand_Turk': 'America/Detroit',
        'America/Guayaquil': 'America/Detroit',
        'America/Havana': 'America/Detroit',
        'America/Indiana/Indianapolis': 'America/Detroit',
        'America/Indiana/Marengo': 'America/Detroit',
        'America/Indiana/Petersburg': 'America/Detroit',
        'America/Indiana/Vevay': 'America/Detroit',
        'America/Indiana/Vincennes': 'America/Detroit',
        'America/Indiana/Winamac': 'America/Detroit',
        'America/Indianapolis': 'America/Detroit',
        'America/Iqaluit': 'America/Detroit',
        'America/Jamaica': 'America/Detroit',
        'America/Kentucky/Louisville': 'America/Detroit',
        'America/Kentucky/Monticello': 'America/Detroit',
        'America/Lima': 'America/Detroit',
        'America/Louisville': 'America/Detroit',
        'America/Montreal': 'America/Detroit',
        'America/Nassau': 'America/Detroit',
        'America/New_York': 'America/Detroit',
        'America/Nipigon': 'America/Detroit',
        'America/Panama': 'America/Detroit',
        'America/Pangnirtung': 'America/Detroit',
        'America/Port-au-Prince': 'America/Detroit',
        'America/Thunder_Bay': 'America/Detroit',
        'America/Toronto': 'America/Detroit',
        'Canada/Eastern': 'America/Detroit',
        'Cuba': 'America/Detroit',
        'EST': 'America/Detroit',
        'EST5EDT': 'America/Detroit',
        'Etc/GMT+5': 'America/Detroit',
        'IET': 'America/Detroit',
        'Jamaica': 'America/Detroit',
        'SystemV/EST5': 'America/Detroit',
        'SystemV/EST5EDT': 'America/Detroit',
        'US/East-Indiana': 'America/Detroit',
        'US/Eastern': 'America/Detroit',
        'US/Michigan': 'America/Detroit',
        /*-4:30*/
        'America/Caracas': 'America/Caracas',
        /*-4:00*/
        'America/Anguilla': 'America/Santiago',
        'America/Antigua': 'America/Santiago',
        'America/Argentina/San_Luis': 'America/Santiago',
        'America/Aruba': 'America/Santiago',
        'America/Asuncion': 'America/Santiago',
        'America/Barbados': 'America/Santiago',
        'America/Blanc-Sablon': 'America/Santiago',
        'America/Boa_Vista': 'America/Santiago',
        'America/Campo_Grande': 'America/Santiago',
        'America/Cuiaba': 'America/Santiago',
        'America/Curacao': 'America/Santiago',
        'America/Dominica': 'America/Santiago',
        'America/Eirunepe': 'America/Santiago',
        'America/Glace_Bay': 'America/Santiago',
        'America/Goose_Bay': 'America/Santiago',
        'America/Grenada': 'America/Santiago',
        'America/Guadeloupe': 'America/Santiago',
        'America/Guyana': 'America/Santiago',
        'America/Halifax': 'America/Santiago',
        'America/Kralendijk': 'America/Santiago',
        'America/La_Paz': 'America/Santiago',
        'America/Lower_Princes': 'America/Santiago',
        'America/Manaus': 'America/Santiago',
        'America/Marigot': 'America/Santiago',
        'America/Martinique': 'America/Santiago',
        'America/Moncton': 'America/Santiago',
        'America/Montserrat': 'America/Santiago',
        'America/Port_of_Spain': 'America/Santiago',
        'America/Porto_Acre': 'America/Santiago',
        'America/Porto_Velho': 'America/Santiago',
        'America/Puerto_Rico': 'America/Santiago',
        'America/Rio_Branco': 'America/Santiago',
        'America/Santiago': 'America/Santiago',
        'America/Santo_Domingo': 'America/Santiago',
        'America/St_Barthelemy': 'America/Santiago',
        'America/St_Kitts': 'America/Santiago',
        'America/St_Lucia': 'America/Santiago',
        'America/St_Thomas': 'America/Santiago',
        'America/St_Vincent': 'America/Santiago',
        'America/Thule': 'America/Santiago',
        'America/Tortola': 'America/Santiago',
        'America/Virgin': 'America/Santiago',
        'Antarctica/Palmer': 'America/Santiago',
        'Atlantic/Bermuda': 'America/Santiago',
        'Brazil/Acre': 'America/Santiago',
        'Brazil/West': 'America/Santiago',
        'Canada/Atlantic': 'America/Santiago',
        'Chile/Continental': 'America/Santiago',
        'Etc/GMT+4': 'America/Santiago',
        'PRT': 'America/Santiago',
        'SystemV/AST4': 'America/Santiago',
        'SystemV/AST4ADT': 'America/Santiago',
        /*-3:30*/
        'America/St_Johns': 'America/St_Johns',
        'CNT': '',
        'Canada/Newfoundland': '',
        /*-3:00*/
        'AGT': 'America/Sao_Paulo',
        'America/Araguaina': 'America/Sao_Paulo',
        'America/Argentina/Buenos_Aires': 'America/Sao_Paulo',
        'America/Argentina/Catamarca': 'America/Sao_Paulo',
        'America/Argentina/ComodRivadavia': 'America/Sao_Paulo',
        'America/Argentina/Cordoba': 'America/Sao_Paulo',
        'America/Argentina/Jujuy': 'America/Sao_Paulo',
        'America/Argentina/La_Rioja': 'America/Sao_Paulo',
        'America/Argentina/Mendoza': 'America/Sao_Paulo',
        'America/Argentina/Rio_Gallegos': 'America/Sao_Paulo',
        'America/Argentina/Salta': 'America/Sao_Paulo',
        'America/Argentina/San_Juan': 'America/Sao_Paulo',
        'America/Argentina/Tucuman': 'America/Sao_Paulo',
        'America/Argentina/Ushuaia': 'America/Sao_Paulo',
        'America/Bahia': 'America/Sao_Paulo',
        'America/Belem': 'America/Sao_Paulo',
        'America/Buenos_Aires': 'America/Sao_Paulo',
        'America/Catamarca': 'America/Sao_Paulo',
        'America/Cayenne': 'America/Sao_Paulo',
        'America/Cordoba': 'America/Sao_Paulo',
        'America/Fortaleza': 'America/Sao_Paulo',
        'America/Godthab': 'America/Sao_Paulo',
        'America/Jujuy': 'America/Sao_Paulo',
        'America/Maceio': 'America/Sao_Paulo',
        'America/Mendoza': 'America/Sao_Paulo',
        'America/Miquelon': 'America/Sao_Paulo',
        'America/Montevideo': 'America/Sao_Paulo',
        'America/Paramaribo': 'America/Sao_Paulo',
        'America/Recife': 'America/Sao_Paulo',
        'America/Rosario': 'America/Sao_Paulo',
        'America/Santarem': 'America/Sao_Paulo',
        'America/Sao_Paulo': 'America/Sao_Paulo',
        'Antarctica/Rothera': 'America/Sao_Paulo',
        'Atlantic/Stanley': 'America/Sao_Paulo',
        'BET': 'America/Sao_Paulo',
        'Brazil/East': 'America/Sao_Paulo',
        'Etc/GMT+3': 'America/Sao_Paulo',
        /*-2:00*/
        'America/Noronha': 'America/Noronha',
        'Atlantic/South_Georgia': 'America/Noronha',
        'Brazil/DeNoronha': 'America/Noronha',
        'Etc/GMT+2': 'America/Noronha',
        /*-1:00*/
        'America/Scoresbysund': 'Atlantic/Cape_Verde',
        'Atlantic/Azores': 'Atlantic/Cape_Verde',
        'Atlantic/Cape_Verde': 'Atlantic/Cape_Verde',
        'Etc/GMT+1': 'Atlantic/Cape_Verde',
        /*+0:00*/
        'Africa/Abidjan': 'Africa/Abidjan',
        'Africa/Accra': 'Africa/Abidjan',
        'Africa/Bamako': 'Africa/Abidjan',
        'Africa/Banjul': 'Africa/Abidjan',
        'Africa/Bissau': 'Africa/Abidjan',
        'Africa/Casablanca': 'Africa/Abidjan',
        'Africa/Conakry': 'Africa/Abidjan',
        'Africa/Dakar': 'Africa/Abidjan',
        'Africa/El_Aaiun': 'Africa/Abidjan',
        'Africa/Freetown': 'Africa/Abidjan',
        'Africa/Lome': 'Africa/Abidjan',
        'Africa/Monrovia': 'Africa/Abidjan',
        'Africa/Nouakchott': 'Africa/Abidjan',
        'Africa/Ouagadougou': 'Africa/Abidjan',
        'Africa/Sao_Tome': 'Africa/Abidjan',
        'Africa/Timbuktu': 'Africa/Abidjan',
        'America/Danmarkshavn': 'Africa/Abidjan',
        'Atlantic/Canary': 'Africa/Abidjan',
        'Atlantic/Faeroe': 'Africa/Abidjan',
        'Atlantic/Faroe': 'Africa/Abidjan',
        'Atlantic/Madeira': 'Africa/Abidjan',
        'Atlantic/Reykjavik': 'Africa/Abidjan',
        'Atlantic/St_Helena': 'Africa/Abidjan',
        'Eire': 'Africa/Abidjan',
        'Etc/GMT': 'Africa/Abidjan',
        'Etc/GMT+0': 'Africa/Abidjan',
        'Etc/GMT-0': 'Africa/Abidjan',
        'Etc/GMT0': 'Africa/Abidjan',
        'Etc/Greenwich': 'Africa/Abidjan',
        'Etc/UCT': 'Africa/Abidjan',
        'Etc/UTC': 'Africa/Abidjan',
        'Etc/Universal': 'Africa/Abidjan',
        'Etc/Zulu': 'Africa/Abidjan',
        'Europe/Belfast': 'Africa/Abidjan',
        'Europe/Dublin': 'Africa/Abidjan',
        'Europe/Guernsey': 'Africa/Abidjan',
        'Europe/Isle_of_Man': 'Africa/Abidjan',
        'Europe/Jersey': 'Africa/Abidjan',
        'Europe/Lisbon': 'Africa/Abidjan',
        'Europe/London': 'Africa/Abidjan',
        'GB': 'Africa/Abidjan',
        'GB-Eire': 'Africa/Abidjan',
        'GMT': 'Africa/Abidjan',
        'GMT0': 'Africa/Abidjan',
        'Greenwich': 'Africa/Abidjan',
        'Iceland': 'Africa/Abidjan',
        'Portugal': 'Africa/Abidjan',
        'UCT': 'Africa/Abidjan',
        'UTC': 'Africa/Abidjan',
        'Universal': 'Africa/Abidjan',
        'WET': 'Africa/Abidjan',
        'Zulu': 'Africa/Abidjan',
        /*+1:00*/
        'Africa/Algiers': 'Europe/Vienna',
        'Africa/Bangui': 'Europe/Vienna',
        'Africa/Brazzaville': 'Europe/Vienna',
        'Africa/Ceuta': 'Europe/Vienna',
        'Africa/Douala': 'Europe/Vienna',
        'Africa/Kinshasa': 'Europe/Vienna',
        'Africa/Lagos': 'Europe/Vienna',
        'Africa/Libreville': 'Europe/Vienna',
        'Africa/Luanda': 'Europe/Vienna',
        'Africa/Malabo': 'Europe/Vienna',
        'Africa/Ndjamena': 'Europe/Vienna',
        'Africa/Niamey': 'Europe/Vienna',
        'Africa/Porto-Novo': 'Europe/Vienna',
        'Africa/Tunis': 'Europe/Vienna',
        'Africa/Windhoek': 'Europe/Vienna',
        'Arctic/Longyearbyen': 'Europe/Vienna',
        'Atlantic/Jan_Mayen': 'Europe/Vienna',
        'CET': 'Europe/Vienna',
        'ECT': 'Europe/Vienna',
        'Etc/GMT-1': 'Europe/Vienna',
        'Europe/Amsterdam': 'Europe/Vienna',
        'Europe/Andorra': 'Europe/Vienna',
        'Europe/Belgrade': 'Europe/Vienna',
        'Europe/Berlin': 'Europe/Vienna',
        'Europe/Bratislava': 'Europe/Vienna',
        'Europe/Brussels': 'Europe/Vienna',
        'Europe/Budapest': 'Europe/Vienna',
        'Europe/Copenhagen': 'Europe/Vienna',
        'Europe/Gibraltar': 'Europe/Vienna',
        'Europe/Ljubljana': 'Europe/Vienna',
        'Europe/Luxembourg': 'Europe/Vienna',
        'Europe/Madrid': 'Europe/Vienna',
        'Europe/Malta': 'Europe/Vienna',
        'Europe/Monaco': 'Europe/Vienna',
        'Europe/Oslo': 'Europe/Vienna',
        'Europe/Paris': 'Europe/Vienna',
        'Europe/Podgorica': 'Europe/Vienna',
        'Europe/Prague': 'Europe/Vienna',
        'Europe/Rome': 'Europe/Vienna',
        'Europe/San_Marino': 'Europe/Vienna',
        'Europe/Sarajevo': 'Europe/Vienna',
        'Europe/Skopje': 'Europe/Vienna',
        'Europe/Stockholm': 'Europe/Vienna',
        'Europe/Tirane': 'Europe/Vienna',
        'Europe/Vaduz': 'Europe/Vienna',
        'Europe/Vatican': 'Europe/Vienna',
        'Europe/Vienna': 'Europe/Vienna',
        'Europe/Warsaw': 'Europe/Vienna',
        'Europe/Zagreb': 'Europe/Vienna',
        'Europe/Zurich': 'Europe/Vienna',
        'MET': 'Europe/Vienna',
        'Poland': 'Europe/Vienna',
        /*+2:00*/
        'ART': 'Asia/Jerusalem',
        'Africa/Blantyre': 'Asia/Jerusalem',
        'Africa/Bujumbura': 'Asia/Jerusalem',
        'Africa/Cairo': 'Asia/Jerusalem',
        'Africa/Gaborone': 'Asia/Jerusalem',
        'Africa/Harare': 'Asia/Jerusalem',
        'Africa/Johannesburg': 'Asia/Jerusalem',
        'Africa/Kigali': 'Asia/Jerusalem',
        'Africa/Lubumbashi': 'Asia/Jerusalem',
        'Africa/Lusaka': 'Asia/Jerusalem',
        'Africa/Maputo': 'Asia/Jerusalem',
        'Africa/Maseru': 'Asia/Jerusalem',
        'Africa/Mbabane': 'Asia/Jerusalem',
        'Africa/Tripoli': 'Asia/Jerusalem',
        'Asia/Amman': 'Asia/Jerusalem',
        'Asia/Beirut': 'Asia/Jerusalem',
        'Asia/Damascus': 'Asia/Jerusalem',
        'Asia/Gaza': 'Asia/Jerusalem',
        'Asia/Hebron': 'Asia/Jerusalem',
        'Asia/Istanbul': 'Asia/Jerusalem',
        'Asia/Jerusalem': 'Asia/Jerusalem',
        'Asia/Nicosia': 'Asia/Jerusalem',
        'Asia/Tel_Aviv': 'Asia/Jerusalem',
        'CAT': 'Asia/Jerusalem',
        'EET': 'Asia/Jerusalem',
        'Egypt': 'Asia/Jerusalem',
        'Etc/GMT-2': 'Asia/Jerusalem',
        'Europe/Athens': 'Asia/Jerusalem',
        'Europe/Bucharest': 'Asia/Jerusalem',
        'Europe/Chisinau': 'Asia/Jerusalem',
        'Europe/Helsinki': 'Asia/Jerusalem',
        'Europe/Istanbul': 'Asia/Jerusalem',
        'Europe/Kiev': 'Asia/Jerusalem',
        'Europe/Mariehamn': 'Asia/Jerusalem',
        'Europe/Nicosia': 'Asia/Jerusalem',
        'Europe/Riga': 'Asia/Jerusalem',
        'Europe/Simferopol': 'Asia/Jerusalem',
        'Europe/Sofia': 'Asia/Jerusalem',
        'Europe/Tallinn': 'Asia/Jerusalem',
        'Europe/Tiraspol': 'Asia/Jerusalem',
        'Europe/Uzhgorod': 'Asia/Jerusalem',
        'Europe/Vilnius': 'Asia/Jerusalem',
        'Europe/Zaporozhye': 'Asia/Jerusalem',
        'Israel': 'Asia/Jerusalem',
        'Libya': 'Asia/Jerusalem',
        'Turkey': 'Asia/Jerusalem',
        /*+3:00*/
        'Africa/Addis_Ababa': 'Africa/Addis_Ababa',
        'Africa/Asmara': 'Africa/Addis_Ababa',
        'Africa/Asmera': 'Africa/Addis_Ababa',
        'Africa/Dar_es_Salaam': 'Africa/Addis_Ababa',
        'Africa/Djibouti': 'Africa/Addis_Ababa',
        'Africa/Juba': 'Africa/Addis_Ababa',
        'Africa/Kampala': 'Africa/Addis_Ababa',
        'Africa/Khartoum': 'Africa/Addis_Ababa',
        'Africa/Mogadishu': 'Africa/Addis_Ababa',
        'Africa/Nairobi': 'Africa/Addis_Ababa',
        'Antarctica/Syowa': 'Africa/Addis_Ababa',
        'Asia/Aden': 'Africa/Addis_Ababa',
        'Asia/Baghdad': 'Africa/Addis_Ababa',
        'Asia/Bahrain': 'Africa/Addis_Ababa',
        'Asia/Kuwait': 'Africa/Addis_Ababa',
        'Asia/Qatar': 'Africa/Addis_Ababa',
        'Asia/Riyadh': 'Africa/Addis_Ababa',
        'EAT': 'Africa/Addis_Ababa',
        'Etc/GMT-3': 'Africa/Addis_Ababa',
        'Europe/Kaliningrad': 'Africa/Addis_Ababa',
        'Europe/Minsk': 'Africa/Addis_Ababa',
        'Indian/Antananarivo': 'Africa/Addis_Ababa',
        'Indian/Comoro': 'Africa/Addis_Ababa',
        'Indian/Mayotte': 'Africa/Addis_Ababa',
        /*+3:30*/
        'Asia/Tehran': 'Asia/Tehran',
        'Iran': 'Asia/Tehran',
        /*+4:00*/
        'Asia/Baku': 'Asia/Dubai',
        'Asia/Dubai': 'Asia/Dubai',
        'Asia/Muscat': 'Asia/Dubai',
        'Asia/Tbilisi': 'Asia/Dubai',
        'Asia/Yerevan': 'Asia/Dubai',
        'Etc/GMT-4': 'Asia/Dubai',
        'Europe/Moscow': 'Asia/Dubai',
        'Europe/Samara': 'Asia/Dubai',
        'Europe/Volgograd': 'Asia/Dubai',
        'Indian/Mahe': 'Asia/Dubai',
        'Indian/Mauritius': 'Asia/Dubai',
        'Indian/Reunion': 'Asia/Dubai',
        'NET': 'Asia/Dubai',
        'W-SU': 'Asia/Dubai',
        /*+4:30*/
        'Asia/Kabul': 'Asia/Kabul',
        /*+5:00*/
        'Antarctica/Mawson': 'Antarctica/Mawson',
        'Asia/Aqtau': 'Antarctica/Mawson',
        'Asia/Aqtobe': 'Antarctica/Mawson',
        'Asia/Ashgabat': 'Antarctica/Mawson',
        'Asia/Ashkhabad': 'Antarctica/Mawson',
        'Asia/Dushanbe': 'Antarctica/Mawson',
        'Asia/Karachi': 'Antarctica/Mawson',
        'Asia/Oral': 'Antarctica/Mawson',
        'Asia/Samarkand': 'Antarctica/Mawson',
        'Asia/Tashkent': 'Antarctica/Mawson',
        'Etc/GMT-5': 'Antarctica/Mawson',
        'Indian/Kerguelen': 'Antarctica/Mawson',
        'Indian/Maldives': 'Antarctica/Mawson',
        'PLT': 'Antarctica/Mawson',
        /*+5:30*/
        'Asia/Calcutta': 'Asia/Colombo',
        'Asia/Colombo': 'Asia/Colombo',
        'Asia/Kolkata': 'Asia/Colombo',
        'IST': 'Asia/Colombo',
        /*+6:00*/
        'Antarctica/Vostok': 'Antarctica/Vostok',
        'Asia/Almaty': 'Antarctica/Vostok',
        'Asia/Bishkek': 'Antarctica/Vostok',
        'Asia/Dacca': 'Antarctica/Vostok',
        'Asia/Dhaka': 'Antarctica/Vostok',
        'Asia/Qyzylorda': 'Antarctica/Vostok',
        'Asia/Thimbu': 'Antarctica/Vostok',
        'Asia/Thimphu': 'Antarctica/Vostok',
        'Asia/Yekaterinburg': 'Antarctica/Vostok',
        'BST': 'Antarctica/Vostok',
        'Etc/GMT-6': 'Antarctica/Vostok',
        'Indian/Chagos': 'Antarctica/Vostok',
        /*+6:30*/
        'Asia/Rangoon': 'Asia/Rangoon',
        'Indian/Cocos': 'Asia/Rangoon',
        /*+7:00*/
        'Antarctica/Davis': 'Antarctica/Davis',
        'Asia/Bangkok': 'Antarctica/Davis',
        'Asia/Ho_Chi_Minh': 'Antarctica/Davis',
        'Asia/Hovd': 'Antarctica/Davis',
        'Asia/Jakarta': 'Antarctica/Davis',
        'Asia/Novokuznetsk': 'Antarctica/Davis',
        'Asia/Novosibirsk': 'Antarctica/Davis',
        'Asia/Omsk': 'Antarctica/Davis',
        'Asia/Phnom_Penh': 'Antarctica/Davis',
        'Asia/Pontianak': 'Antarctica/Davis',
        'Asia/Saigon': 'Antarctica/Davis',
        'Asia/Vientiane': 'Antarctica/Davis',
        'Etc/GMT-7': 'Antarctica/Davis',
        'Indian/Christmas': 'Antarctica/Davis',
        'VST': 'Antarctica/Davis',
        /*+8:00*/
        'Antarctica/Casey': 'Antarctica/Casey',
        'Asia/Brunei': 'Antarctica/Casey',
        'Asia/Choibalsan': 'Antarctica/Casey',
        'Asia/Chongqing': 'Antarctica/Casey',
        'Asia/Chungking': 'Antarctica/Casey',
        'Asia/Harbin': 'Antarctica/Casey',
        'Asia/Hong_Kong': 'Antarctica/Casey',
        'Asia/Kashgar': 'Antarctica/Casey',
        'Asia/Krasnoyarsk': 'Antarctica/Casey',
        'Asia/Kuala_Lumpur': 'Antarctica/Casey',
        'Asia/Kuching': 'Antarctica/Casey',
        'Asia/Macao': 'Antarctica/Casey',
        'Asia/Macau': 'Antarctica/Casey',
        'Asia/Makassar': 'Antarctica/Casey',
        'Asia/Manila': 'Antarctica/Casey',
        'Asia/Shanghai': 'Antarctica/Casey',
        'Asia/Singapore': 'Antarctica/Casey',
        'Asia/Taipei': 'Antarctica/Casey',
        'Asia/Ujung_Pandang': 'Antarctica/Casey',
        'Asia/Ulaanbaatar': 'Antarctica/Casey',
        'Asia/Ulan_Bator': 'Antarctica/Casey',
        'Asia/Urumqi': 'Antarctica/Casey',
        'Australia/Perth': 'Antarctica/Casey',
        'Australia/West': 'Antarctica/Casey',
        'CTT': 'Antarctica/Casey',
        'Etc/GMT-8': 'Antarctica/Casey',
        'Hongkong': 'Antarctica/Casey',
        'PRC': 'Antarctica/Casey',
        'Singapore': 'Antarctica/Casey',
        /*+9:00*/
        'Asia/Dili': 'Asia/Dili',
        'Asia/Irkutsk': 'Asia/Dili',
        'Asia/Jayapura': 'Asia/Dili',
        'Asia/Pyongyang': 'Asia/Dili',
        'Asia/Seoul': 'Asia/Dili',
        'Asia/Tokyo': 'Asia/Dili',
        'Etc/GMT-9': 'Asia/Dili',
        'JST': 'Asia/Dili',
        'Japan': 'Asia/Dili',
        'Pacific/Palau': 'Asia/Dili',
        'ROK': 'Asia/Dili',
        /*+9:30*/
        'ACT': 'Australia/Darwin',
        'Australia/Adelaide': 'Australia/Darwin',
        'Australia/Broken_Hill': 'Australia/Darwin',
        'Australia/Darwin': 'Australia/Darwin',
        'Australia/North': 'Australia/Darwin',
        'Australia/South': 'Australia/Darwin',
        'Australia/Yancowinna': 'Australia/Darwin',
        /*+10:00*/
        'AET': 'Australia/Currie',
        'Antarctica/DumontDUrville': 'Australia/Currie',
        'Asia/Yakutsk': 'Australia/Currie',
        'Australia/ACT': 'Australia/Currie',
        'Australia/Brisbane': 'Australia/Currie',
        'Australia/Canberra': 'Australia/Currie',
        'Australia/Currie': 'Australia/Currie',
        'Australia/Hobart': 'Australia/Currie',
        'Australia/Lindeman': 'Australia/Currie',
        'Australia/Melbourne': 'Australia/Currie',
        'Australia/NSW': 'Australia/Currie',
        'Australia/Queensland': 'Australia/Currie',
        'Australia/Sydney': 'Australia/Currie',
        'Australia/Tasmania': 'Australia/Currie',
        'Australia/Victoria': 'Australia/Currie',
        'Etc/GMT-10': 'Australia/Currie',
        'Pacific/Chuuk': 'Australia/Currie',
        'Pacific/Guam': 'Australia/Currie',
        'Pacific/Port_Moresby': 'Australia/Currie',
        'Pacific/Saipan': 'Australia/Currie',
        'Pacific/Truk': 'Australia/Currie',
        'Pacific/Yap': 'Australia/Currie',
        /*+10:30*/
        'Australia/LHI': 'Australia/Lord_Howe',
        'Australia/Lord_Howe': 'Australia/Lord_Howe',
        /*+11:00*/
        'Antarctica/Macquarie': 'Antarctica/Macquarie',
        'Asia/Sakhalin': 'Antarctica/Macquarie',
        'Asia/Vladivostok': 'Antarctica/Macquarie',
        'Etc/GMT-11': 'Antarctica/Macquarie',
        'Pacific/Efate': 'Antarctica/Macquarie',
        'Pacific/Guadalcanal': 'Antarctica/Macquarie',
        'Pacific/Kosrae': 'Antarctica/Macquarie',
        'Pacific/Noumea': 'Antarctica/Macquarie',
        'Pacific/Pohnpei': 'Antarctica/Macquarie',
        'Pacific/Ponape': 'Antarctica/Macquarie',
        'SST': 'Antarctica/Macquarie',
        /*+11:30*/
        'Pacific/Norfolk': 'Pacific/Norfolk',
        /*+12:00*/
        'Antarctica/McMurdo': 'Antarctica/McMurdo',
        'Antarctica/South_Pole': 'Antarctica/McMurdo',
        'Asia/Anadyr': 'Antarctica/McMurdo',
        'Asia/Kamchatka': 'Antarctica/McMurdo',
        'Asia/Magadan': 'Antarctica/McMurdo',
        'Etc/GMT-12': 'Antarctica/McMurdo',
        'Kwajalein': 'Antarctica/McMurdo',
        'NST': 'Antarctica/McMurdo',
        'NZ': 'Antarctica/McMurdo',
        'Pacific/Auckland': 'Antarctica/McMurdo',
        'Pacific/Fiji': 'Antarctica/McMurdo',
        'Pacific/Funafuti': 'Antarctica/McMurdo',
        'Pacific/Kwajalein': 'Antarctica/McMurdo',
        'Pacific/Majuro': 'Antarctica/McMurdo',
        'Pacific/Nauru': 'Antarctica/McMurdo',
        'Pacific/Tarawa': 'Antarctica/McMurdo',
        'Pacific/Wake': 'Antarctica/McMurdo',
        'Pacific/Wallis': 'Antarctica/McMurdo',
        /*+13:00*/
        'Etc/GMT-13': 'Pacific/Enderbury',
        'MIT': 'Pacific/Enderbury',
        'Pacific/Apia': 'Pacific/Enderbury',
        'Pacific/Enderbury': 'Pacific/Enderbury',
        'Pacific/Tongatapu': 'Pacific/Enderbury',
        /*+14:00*/
        'Etc/GMT-14': 'Pacific/Kiritimati',
        'Pacific/Fakaofo': 'Pacific/Kiritimati',
        'Pacific/Kiritimati': 'Pacific/Kiritimati'
    },

    /* return unmapped timezone... */
    unMap: function (timezone) {
        return this.map[timezone] !== undefined ? this.map[timezone] : timezone;
    },

    getOffset: function (timezone) {
        /* find timezone, this needs to be optimized ;) */
        timezone = this.unMap(timezone);
        var i = 0;
        for (i = 0; i < this.store.length; i++) {
            if (this.store[i][0] == timezone) {
                return (this.store[i][2] * 60000);
            }
        }

        return 0;	// no offset found...
    }
});

Zarafa.plugins.calendarimporter.data.Timezones = new Zarafa.plugins.calendarimporter.data.Timezones();/**
 * ImportContentPanel.js, Kopano calender to ics im/exporter
 *
 * Author: Christoph Haas <christoph.h@sprinternet.at>
 * Copyright (C) 2012-2018 Christoph Haas
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

/**
 * ImportContentPanel
 *
 * Container for the importpanel.
 */
Ext.namespace("Zarafa.plugins.calendarimporter.dialogs");

/**
 * @class Zarafa.plugins.calendarimporter.dialogs.ImportContentPanel
 * @extends Zarafa.core.ui.ContentPanel
 *
 * The content panel which shows the hierarchy tree of Owncloud account files.
 * @xtype calendarimportercontentpanel
 */
Zarafa.plugins.calendarimporter.dialogs.ImportContentPanel = Ext.extend(Zarafa.core.ui.ContentPanel, {

    /**
     * @constructor
     * @param config Configuration structure
     */
    constructor: function (config) {
        config = config || {};
        Ext.applyIf(config, {
            layout: 'fit',
            title: dgettext('plugin_calendarimporter', 'Import Calendar File'),
            closeOnSave: true,
            width: 800,
            height: 700,
            //Add panel
            items: [
                {
                    xtype: 'calendarimporter.importpanel',
                    filename: config.filename,
                    folder: config.folder
                }
            ]
        });

        Zarafa.plugins.calendarimporter.dialogs.ImportContentPanel.superclass.constructor.call(this, config);
    }

});

Ext.reg('calendarimporter.contentpanel', Zarafa.plugins.calendarimporter.dialogs.ImportContentPanel);/**
 * ImportPanel.js, Kopano calender to ics im/exporter
 *
 * Author: Christoph Haas <christoph.h@sprinternet.at>
 * Copyright (C) 2012-2018 Christoph Haas
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

/**
 * ImportPanel
 *
 * The main Panel of the calendarimporter plugin.
 */
Ext.namespace("Zarafa.plugins.calendarimporter.dialogs");

/**
 * @class Zarafa.plugins.calendarimporter.dialogs.ImportPanel
 * @extends Ext.Panel
 */
Zarafa.plugins.calendarimporter.dialogs.ImportPanel = Ext.extend(Ext.Panel, {

    /* store the imported timezone here... */
    timezone: null,

    /* ignore daylight saving time... */
    ignoredst: null,

    /* path to ics file on server... */
    icsfile: null,

    /* loadmask for timezone/dst changes... */
    loadMask: null,

    /* export event buffer */
    exportResponse: [],

    /* how many requests are still running? */
    runningRequests: null,

    /* The store for the selection grid */
    store: null,

    /* selected folder */
    folder: null,

    /**
     * @constructor
     * @param {object} config
     */
    constructor: function (config) {
        config = config || {};
        var self = this;
        this.timezone = container.getSettingsModel().get("zarafa/v1/plugins/calendarimporter/default_timezone");

        if (!Ext.isEmpty(config.filename)) {
            this.icsfile = config.filename;
        }

        if (!Ext.isEmpty(config.folder)) {
            this.folder = config.folder;
        }

        // create the data store
        this.store = new Ext.data.ArrayStore({
            fields: [
                {name: 'subject'},
                {name: 'startdate'},
                {name: 'enddate'},
                {name: 'location'},
                {name: 'body'},
                {name: 'priority'},
                {name: 'label'},
                {name: 'busy'},
                {name: 'class'},
                {name: 'organizer'},
                {name: 'alarms'},
                {name: 'timezone'},
                {name: 'record'}
            ]
        });

        Ext.apply(config, {
            xtype: 'calendarimporter.importpanel',
            ref: "importpanel",
            id: "importpanel",
            layout: {
                type: 'form',
                align: 'stretch'
            },
            anchor: '100%',
            bodyStyle: 'background-color: inherit;',
            defaults: {
                border: true,
                bodyStyle: 'background-color: inherit; padding: 3px 0px 3px 0px; border-style: none none solid none;'
            },
            items: [
                this.createSelectBox(),
                this.createTimezoneBox(),
                this.createDaylightSavingCheckBox(),
                this.initForm(),
                this.createGrid()
            ],
            buttons: [
                this.createSubmitAllButton(),
                this.createSubmitButton(),
                this.createCancelButton()
            ],
            listeners: {
                afterrender: function (cmp) {
                    this.loadMask = new Ext.LoadMask(this.getEl(), {msg: dgettext('plugin_calendarimporter', 'Loading...')});

                    if (this.icsfile != null) { // if we have got the filename from an attachment
                        this.parseCalendar(this.icsfile, this.timezone, this.ignoredst);
                    }
                },
                scope: this
            }
        });

        Zarafa.plugins.calendarimporter.dialogs.ImportPanel.superclass.constructor.call(this, config);
    },

    /**
     * Init embedded form, this is the form that is
     * posted and contains the attachments
     * @private
     */
    initForm: function () {
        return {
            xtype: 'form',
            ref: 'addFormPanel',
            layout: 'column',
            fileUpload: true,
            autoWidth: true,
            autoHeight: true,
            border: false,
            bodyStyle: 'padding: 5px;',
            defaults: {
                anchor: '95%',
                border: false,
                bodyStyle: 'padding: 5px;'
            },
            items: [this.createUploadField()]
        };
    },

    /**
     * Reloads the data of the grid
     * @private
     */
    reloadGridStore: function (eventdata) {
        var parsedData = [];

        if (eventdata !== null) {
            parsedData = new Array(eventdata.events.length);
            var i = 0;
            for (i = 0; i < eventdata.events.length; i++) {
                parsedData[i] = [
                    eventdata.events[i]["subject"],
                    new Date(parseInt(eventdata.events[i]["startdate"]) * 1000),
                    new Date(parseInt(eventdata.events[i]["duedate"]) * 1000),
                    eventdata.events[i]["location"],
                    eventdata.events[i]["body"],
                    eventdata.events[i]["priority"],
                    eventdata.events[i]["label"],
                    eventdata.events[i]["busystatus"],
                    eventdata.events[i]["private"],
                    eventdata.events[i]["organizer"],
                    eventdata.events[i]["alarms"],
                    eventdata.events[i]["timezone"],
                    eventdata.events[i]
                ];
            }
        } else {
            return null;
        }

        this.store.loadData(parsedData, false);
    },

    /**
     * Init embedded form, this is the form that is
     * posted and contains the attachments
     * @private
     */
    createGrid: function () {
        return {
            xtype: 'grid',
            ref: 'eventgrid',
            id: 'eventgrid',
            columnWidth: 1.0,
            store: this.store,
            width: '100%',
            height: 300,
            title: dgettext('plugin_calendarimporter', 'Select events to import'),
            frame: false,
            viewConfig: {
                forceFit: true
            },
            colModel: new Ext.grid.ColumnModel({
                defaults: {
                    width: 300,
                    sortable: true
                },
                columns: [
                    {
                        id: 'Summary',
                        header: dgettext('plugin_calendarimporter', 'Title'),
                        width: 200,
                        sortable: true,
                        dataIndex: 'subject'
                    },
                    {
                        header: dgettext('plugin_calendarimporter', 'Start'),
                        width: 200,
                        sortable: true,
                        dataIndex: 'startdate',
                        renderer: Zarafa.common.ui.grid.Renderers.datetime
                    },
                    {
                        header: dgettext('plugin_calendarimporter', 'End'),
                        width: 200,
                        sortable: true,
                        dataIndex: 'enddate',
                        renderer: Zarafa.common.ui.grid.Renderers.datetime
                    },
                    {
                        header: dgettext('plugin_calendarimporter', 'Location'),
                        width: 150,
                        sortable: true,
                        dataIndex: 'location'
                    },
                    {header: dgettext('plugin_calendarimporter', 'Description'), sortable: true, dataIndex: 'body'},
                    {header: dgettext('plugin_calendarimporter', 'Priority'), dataIndex: 'priority', hidden: true},
                    {header: dgettext('plugin_calendarimporter', 'Label'), dataIndex: 'label', hidden: true},
                    {header: dgettext('plugin_calendarimporter', 'Busystatus'), dataIndex: 'busy', hidden: true},
                    {header: dgettext('plugin_calendarimporter', 'Privacystatus'), dataIndex: 'class', hidden: true},
                    {header: dgettext('plugin_calendarimporter', 'Organizer'), dataIndex: 'organizer', hidden: true},
                    {
                        header: dgettext('plugin_calendarimporter', 'Alarm'),
                        dataIndex: 'alarms',
                        hidden: true,
                        renderer: Zarafa.common.ui.grid.Renderers.datetime
                    },
                    {header: dgettext('plugin_calendarimporter', 'Timezone'), dataIndex: 'timezone', hidden: true}
                ]
            }),
            sm: new Ext.grid.RowSelectionModel({multiSelect: true})
        }
    },

    createSelectBox: function () {
        var myStore = Zarafa.plugins.calendarimporter.data.Actions.getAllCalendarFolders(true);

        return {
            xtype: "selectbox",
            ref: 'calendarselector',
            editable: false,
            name: "choosen_calendar",
            value: Ext.isEmpty(this.folder) ? Zarafa.plugins.calendarimporter.data.Actions.getCalendarFolderByName(container.getSettingsModel().get("zarafa/v1/plugins/calendarimporter/default_calendar")).entryid : this.folder,
            width: 100,
            fieldLabel: dgettext('plugin_calendarimporter', 'Select folder'),
            store: myStore,
            mode: 'local',
            labelSeperator: ":",
            border: false,
            anchor: "100%",
            scope: this,
            hidden: Ext.isEmpty(this.folder) ? false : true,
            allowBlank: false
        }
    },

    createTimezoneBox: function () {
        return {
            xtype: "selectbox",
            ref: 'timezoneselector',
            editable: false,
            name: "choosen_timezone",
            value: Zarafa.plugins.calendarimporter.data.Timezones.unMap(container.getSettingsModel().get("zarafa/v1/plugins/calendarimporter/default_timezone")),
            width: 100,
            fieldLabel: dgettext('plugin_calendarimporter', 'Timezone'),
            store: Zarafa.plugins.calendarimporter.data.Timezones.store,
            labelSeperator: ":",
            mode: 'local',
            border: false,
            anchor: "100%",
            scope: this,
            allowBlank: true,
            listeners: {
                select: this.onTimezoneSelected,
                scope: this
            }
        }
    },

    createDaylightSavingCheckBox: function () {
        return {
            xtype: "checkbox",
            ref: 'dstcheck',
            name: "dst_check",
            width: 100,
            fieldLabel: dgettext('plugin_calendarimporter', 'Ignore DST'),
            boxLabel: dgettext('plugin_calendarimporter', 'This will ignore "Daylight saving time" offsets.'),
            labelSeperator: ":",
            border: false,
            anchor: "100%",
            scope: this,
            allowBlank: true,
            listeners: {
                check: this.onDstChecked,
                scope: this
            }
        }
    },

    createUploadField: function () {
        return {
            xtype: "fileuploadfield",
            ref: 'fileuploadfield',
            columnWidth: 1.0,
            id: 'form-file',
            name: 'icsdata',
            emptyText: dgettext('plugin_calendarimporter', 'Select an .ics calendar'),
            border: false,
            anchor: "100%",
            height: "30",
            scope: this,
            allowBlank: false,
            listeners: {
                fileselected: this.onFileSelected,
                scope: this
            }
        }
    },

    createSubmitButton: function () {
        return {
            xtype: "button",
            ref: "../submitButton",
            disabled: true,
            width: 100,
            border: false,
            text: dgettext('plugin_calendarimporter', 'Import'),
            anchor: "100%",
            handler: this.importCheckedEvents,
            scope: this
        }
    },

    createSubmitAllButton: function () {
        return {
            xtype: "button",
            ref: "../submitAllButton",
            disabled: true,
            width: 100,
            border: false,
            text: dgettext('plugin_calendarimporter', 'Import All'),
            anchor: "100%",
            handler: this.importAllEvents,
            scope: this
        }
    },

    createCancelButton: function () {
        return {
            xtype: "button",
            width: 100,
            border: false,
            text: dgettext('plugin_calendarimporter', 'Cancel'),
            anchor: "100%",
            handler: this.close,
            scope: this
        }
    },

    /**
     * This is called when a timezone has been seleceted in the timezone dialog
     * @param {Ext.form.ComboBox} combo
     * @param {Ext.data.Record} record
     * @param {Number} index
     */
    onTimezoneSelected: function (combo, record, index) {
        this.timezone = record.data.field1;

        if (this.icsfile != null) {
            this.parseCalendar(this.icsfile, this.timezone, this.ignoredst);
        }
    },

    /**
     * This is called when the dst checkbox has been selected
     * @param {Ext.form.CheckBox} checkbox
     * @param {boolean} checked
     */
    onDstChecked: function (checkbox, checked) {
        this.ignoredst = checked;

        if (this.icsfile != null) {
            this.parseCalendar(this.icsfile, this.timezone, this.ignoredst);
        }
    },

    /**
     * This is called when a file has been seleceted in the file dialog
     * in the {@link Ext.ux.form.FileUploadField} and the dialog is closed
     * @param {Ext.ux.form.FileUploadField} uploadField being added a file to
     */
    onFileSelected: function (uploadField) {
        var form = this.addFormPanel.getForm();

        if (form.isValid()) {
            form.submit({
                waitMsg: dgettext('plugin_calendarimporter', 'Uploading and parsing calendar...'),
                url: 'plugins/calendarimporter/php/upload.php',
                failure: function (file, action) {
                    this.submitButton.disable();
                    this.submitAllButton.disable();
                    Zarafa.common.dialogs.MessageBox.show({
                        title: _('Error'),
                        msg: action.result.error,
                        icon: Zarafa.common.dialogs.MessageBox.ERROR,
                        buttons: Zarafa.common.dialogs.MessageBox.OK
                    });
                },
                success: function (file, action) {
                    uploadField.reset();
                    this.icsfile = action.result.ics_file;

                    this.parseCalendar(this.icsfile, this.timezone, this.ignoredst);
                },
                scope: this
            });
        }
    },

    parseCalendar: function (icsPath, timezone, ignoredst) {
        this.loadMask.show();

        var responseHandler = new Zarafa.plugins.calendarimporter.data.ResponseHandler({
            successCallback: this.handleParsingResult,
            scope: this
        });

        container.getRequest().singleRequest(
            'calendarmodule',
            'load',
            {
                ics_filepath: icsPath,
                timezone: timezone,
                ignore_dst: ignoredst
            },
            responseHandler
        );
    },

    handleParsingResult: function (response) {
        var self = this.scope;

        self.loadMask.hide();

        if (response["status"] == true) {
            self.submitButton.enable();
            self.submitAllButton.enable();

            if (typeof response.parsed.calendar["X-WR-TIMEZONE"] !== "undefined") {
                self.timezone = response.parsed.calendar["X-WR-TIMEZONE"];
                self.timezoneselector.setValue(Zarafa.plugins.calendarimporter.data.Timezones.unMap(this.timezone));
            }
            self.reloadGridStore(response.parsed);
        } else {
            self.submitButton.disable();
            self.submitAllButton.disable();
            Zarafa.common.dialogs.MessageBox.show({
                title: dgettext('plugin_calendarimporter', 'Parser Error'),
                msg: response["message"],
                icon: Zarafa.common.dialogs.MessageBox.ERROR,
                buttons: Zarafa.common.dialogs.MessageBox.OK
            });
        }
    },

    close: function () {
        this.addFormPanel.getForm().reset();
        this.dialog.close()
    },

    importCheckedEvents: function () {
        var newRecords = this.eventgrid.selModel.getSelections();
        this.importEvents(newRecords);
    },

    importAllEvents: function () {
        //receive Records from grid rows
        this.eventgrid.selModel.selectAll();  // select all entries
        var newRecords = this.eventgrid.selModel.getSelections();
        this.importEvents(newRecords);
    },

    /**
     * This function stores all given events to the appointmentstore
     * @param events
     */
    importEvents: function (events) {
        //receive existing calendar store
        var calValue = this.calendarselector.getValue();

        if (Ext.isEmpty(calValue)) { // no calendar choosen
            Zarafa.common.dialogs.MessageBox.show({
                title: dgettext('plugin_calendarimporter', 'Error'),
                msg: dgettext('plugin_calendarimporter', 'You have to choose a calendar!'),
                icon: Zarafa.common.dialogs.MessageBox.ERROR,
                buttons: Zarafa.common.dialogs.MessageBox.OK
            });
        } else {
            if (this.eventgrid.selModel.getCount() < 1) {
                Zarafa.common.dialogs.MessageBox.show({
                    title: dgettext('plugin_calendarimporter', 'Error'),
                    msg: dgettext('plugin_calendarimporter', 'You have to choose at least one event to import!'),
                    icon: Zarafa.common.dialogs.MessageBox.ERROR,
                    buttons: Zarafa.common.dialogs.MessageBox.OK
                });
            } else {
                var calendarFolder = Zarafa.plugins.calendarimporter.data.Actions.getCalendarFolderByEntryid(calValue);

                this.loadMask.show();
                var uids = [];

                //receive Records from grid rows
                Ext.each(events, function (newRecord) {
                    uids.push(newRecord.data.record.internal_fields.event_uid);
                }, this);

                var responseHandler = new Zarafa.plugins.calendarimporter.data.ResponseHandler({
                    successCallback: this.importEventsDone,
                    scope: this
                });

                container.getRequest().singleRequest(
                    'calendarmodule',
                    'import',
                    {
                        storeid: calendarFolder.store_entryid,
                        folderid: calendarFolder.entryid,
                        uids: uids,
                        ics_filepath: this.icsfile
                    },
                    responseHandler
                );
            }
        }
    },

    /**
     * Callback for the import request.
     * @param {Object} response
     */
    importEventsDone: function (response) {
        var self = this.scope;

        self.loadMask.hide();
        self.dialog.close();
        if (response.status == true) {
            container.getNotifier().notify('info', 'Imported', 'Imported ' + response.count + ' events. Please reload your calendar!');
        } else {
            Zarafa.common.dialogs.MessageBox.show({
                title: dgettext('plugin_calendarimporter', 'Error'),
                msg: String.format(dgettext('plugin_calendarimporter', 'Import failed: {0}'), response.message),
                icon: Zarafa.common.dialogs.MessageBox.ERROR,
                buttons: Zarafa.common.dialogs.MessageBox.OK
            });
        }
    }
});

Ext.reg('calendarimporter.importpanel', Zarafa.plugins.calendarimporter.dialogs.ImportPanel);
Ext.util.base64 = {
	base64s : "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/",

	encode: function(decStr){
		if (typeof btoa === 'function') {
			 return btoa(decStr);            
		}
		var base64s = this.base64s;
		var bits;
		var dual;
		var i = 0;
		var encOut = "";
		while(decStr.length >= i + 3){
			bits = (decStr.charCodeAt(i++) & 0xff) <<16 | (decStr.charCodeAt(i++) & 0xff) <<8 | decStr.charCodeAt(i++) & 0xff;
			encOut += base64s.charAt((bits & 0x00fc0000) >>18) + base64s.charAt((bits & 0x0003f000) >>12) + base64s.charAt((bits & 0x00000fc0) >> 6) + base64s.charAt((bits & 0x0000003f));
		}
		if(decStr.length -i > 0 && decStr.length -i < 3){
			dual = Boolean(decStr.length -i -1);
			bits = ((decStr.charCodeAt(i++) & 0xff) <<16) |    (dual ? (decStr.charCodeAt(i) & 0xff) <<8 : 0);
			encOut += base64s.charAt((bits & 0x00fc0000) >>18) + base64s.charAt((bits & 0x0003f000) >>12) + (dual ? base64s.charAt((bits & 0x00000fc0) >>6) : '=') + '=';
		}
		return(encOut);
	},

	decode: function(encStr){
		if (typeof atob === 'function') {
			return atob(encStr); 
		}
		var base64s = this.base64s;        
		var bits;
		var decOut = "";
		var i = 0;
		for(; i<encStr.length; i += 4){
			bits = (base64s.indexOf(encStr.charAt(i)) & 0xff) <<18 | (base64s.indexOf(encStr.charAt(i +1)) & 0xff) <<12 | (base64s.indexOf(encStr.charAt(i +2)) & 0xff) << 6 | base64s.indexOf(encStr.charAt(i +3)) & 0xff;
			decOut += String.fromCharCode((bits & 0xff0000) >>16, (bits & 0xff00) >>8, bits & 0xff);
		}
		if(encStr.charCodeAt(i -2) == 61){
			return(decOut.substring(0, decOut.length -2));
		}
		else if(encStr.charCodeAt(i -1) == 61){
			return(decOut.substring(0, decOut.length -1));
		}
		else {
			return(decOut);
		}
	}
}/**
 * plugin.calendarimporter.js, Kopano calender to ics im/exporter
 *
 * Author: Christoph Haas <christoph.h@sprinternet.at>
 * Copyright (C) 2012-2018 Christoph Haas
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

Ext.namespace("Zarafa.plugins.calendarimporter");									// Assign the right namespace

Zarafa.plugins.calendarimporter.ImportPlugin = Ext.extend(Zarafa.core.Plugin, {		// create new import plugin

    /**
     * @constructor
     * @param {Object} config Configuration object
     *
     */
    constructor: function (config) {
        config = config || {};

        Zarafa.plugins.calendarimporter.ImportPlugin.superclass.constructor.call(this, config);
    },

    /**
     * initialises insertion point for plugin
     * @protected
     */
    initPlugin: function () {
        Zarafa.plugins.calendarimporter.ImportPlugin.superclass.initPlugin.apply(this, arguments);

        /* our panel */
        Zarafa.core.data.SharedComponentType.addProperty('plugins.calendarimporter.dialogs.importevents');

        /* directly import received icals */
        this.registerInsertionPoint('common.contextmenu.attachment.actions', this.createAttachmentImportButton);

        /* add settings widget */
        this.registerInsertionPoint('context.settings.category.calendar', this.createSettingsWidget);

        /* export a calendar entry via rightclick */
        this.registerInsertionPoint('context.calendar.contextmenu.actions', this.createItemExportInsertionPoint, this);

        /* ical sync stuff */
        if (container.getSettingsModel().get("zarafa/v1/plugins/calendarimporter/enable_sync") === true) {
            /* edit panel */
            Zarafa.core.data.SharedComponentType.addProperty('plugins.calendarimporter.settings.dialogs.calsyncedit');

            /* enable the settings widget */
            this.registerInsertionPoint('context.settings.category.calendar', this.createSettingsCalSyncWidget);
        }
    },

    /**
     * This method hooks to the contact context menu and allows users to export users to vcf.
     *
     * @param include
     * @param btn
     * @returns {Object}
     */
    createItemExportInsertionPoint: function (include, btn) {
        return {
            text: dgettext('plugin_calendarimporter', 'Export Event'),
            handler: this.exportToICS.createDelegate(this, [btn]),
            scope: this,
            iconCls: 'icon_calendarimporter_export'
        };
    },

    /**
     * Generates a request to download the selected records as vCard.
     * @param {Ext.Button} btn
     */
    exportToICS: function (btn) {
        if (btn.records.length == 0) {
            return; // skip if no records where given!
        }

        var recordIds = [];

        for (var i = 0; i < btn.records.length; i++) {
            recordIds.push(btn.records[i].get("entryid"));
        }

        Zarafa.plugins.calendarimporter.data.Actions.exportToICS(btn.records[0].get("store_entryid"), recordIds, undefined);
    },

    /**
     * Creates the button
     *
     * @return {Object} Configuration object for a {@link Ext.Button button}
     *
     */
    createSettingsWidget: function () {
        return [{
            xtype: 'calendarimporter.settingswidget'
        }];
    },

    /**
     * Creates the button
     *
     * @return {Object} Configuration object for a {@link Ext.Button button}
     *
     */
    createSettingsCalSyncWidget: function () {
        return [{
            xtype: 'calendarimporter.settingscalsyncwidget'
        }];
    },

    /**
     * Insert import button in all attachment suggestions

     * @return {Object} Configuration object for a {@link Ext.Button button}
     */
    createAttachmentImportButton: function (include, btn) {
        return {
            text: dgettext('plugin_calendarimporter', 'Import to Calendar'),
            handler: this.getAttachmentFileName.createDelegate(this, [btn]),
            scope: this,
            iconCls: 'icon_calendarimporter_button',
            beforeShow: function (item, record) {
                var extension = record.data.name.split('.').pop().toLowerCase();

                if (record.data.filetype == "text/calendar" || extension == "ics" || extension == "ifb" || extension == "ical" || extension == "ifbf") {
                    item.setVisible(true);
                } else {
                    item.setVisible(false);
                }
            }
        };
    },

    /**
     * Callback for getAttachmentFileName
     */
    gotAttachmentFileName: function (response) {
        if (response.status == true) {
            this.scope.openImportDialog(response.tmpname);
        } else {
            Zarafa.common.dialogs.MessageBox.show({
                title: dgettext('plugin_calendarimporter', 'Error'),
                msg: response["message"],
                icon: Zarafa.common.dialogs.MessageBox.ERROR,
                buttons: Zarafa.common.dialogs.MessageBox.OK
            });
        }
    },

    /**
     * Clickhandler for the button
     */
    getAttachmentFileName: function (btn, callback) {
        Zarafa.common.dialogs.MessageBox.show({
            title: dgettext('plugin_calendarimporter', 'Please wait'),
            msg: dgettext('plugin_calendarimporter', 'Loading attachment...'),
            progressText: dgettext('plugin_calendarimporter', 'Initializing...'),
            width: 300,
            progress: true,
            closable: false
        });

        // progress bar... ;)
        var f = function (v) {
            return function () {
                if (v == 100) {
                    Zarafa.common.dialogs.MessageBox.hide();
                } else {
                    // # TRANSLATORS: {0} will be replaced by the percentage value (0-100)
                    Zarafa.common.dialogs.MessageBox.updateProgress(v / 100, String.format(dgettext('plugin_calendarimporter', '{0}% loaded'), Math.round(v)));
                }
            };
        };

        for (var i = 1; i < 101; i++) {
            setTimeout(f(i), 20 * i);
        }

        /* store the attachment to a temporary folder and prepare it for uploading */
        var attachmentRecord = btn.records;
        var attachmentStore = attachmentRecord.store;

        var store = attachmentStore.getParentRecord().get('store_entryid');
        var entryid = attachmentStore.getAttachmentParentRecordEntryId();
        var attachNum = new Array(1);
        if (attachmentRecord.get('attach_num') != -1) {
            attachNum[0] = attachmentRecord.get('attach_num');
        } else {
            attachNum[0] = attachmentRecord.get('tmpname');
        }
        var dialog_attachments = attachmentStore.getId();
        var filename = attachmentRecord.data.name;

        var responseHandler = new Zarafa.plugins.calendarimporter.data.ResponseHandler({
            successCallback: this.gotAttachmentFileName,
            scope: this
        });

        // request attachment preperation
        container.getRequest().singleRequest(
            'calendarmodule',
            'importattachment',
            {
                entryid: entryid,
                store: store,
                attachNum: attachNum,
                dialog_attachments: dialog_attachments,
                filename: filename
            },
            responseHandler
        );
    },

    /**
     * Open the import dialog.
     * @param {String} filename
     */
    openImportDialog: function (filename) {
        var componentType = Zarafa.core.data.SharedComponentType['plugins.calendarimporter.dialogs.importevents'];
        var config = {
            filename: filename,
            modal: true
        };

        Zarafa.core.data.UIFactory.openLayerComponent(componentType, undefined, config);
    },

    /**
     * Bid for the type of shared component
     * and the given record.
     * This will bid on calendar.dialogs.importevents
     * @param {Zarafa.core.data.SharedComponentType} type Type of component a context can bid for.
     * @param {Ext.data.Record} record Optionally passed record.
     * @return {Number} The bid for the shared component
     */
    bidSharedComponent: function (type, record) {
        var bid = -1;
        switch (type) {
            case Zarafa.core.data.SharedComponentType['plugins.calendarimporter.dialogs.importevents']:
                bid = 2;
                break;
            case Zarafa.core.data.SharedComponentType['plugins.calendarimporter.settings.dialogs.calsyncedit']:
                bid = 2;
                break;
            case Zarafa.core.data.SharedComponentType['common.contextmenu']:
                if (record instanceof Zarafa.core.data.MAPIRecord) {
                    if (record.get('object_type') == Zarafa.core.mapi.ObjectType.MAPI_FOLDER && record.get('container_class') == "IPF.Appointment") {
                        bid = 2;
                    }
                }
                break;
        }
        return bid;
    },

    /**
     * Will return the reference to the shared component.
     * Based on the type of component requested a component is returned.
     * @param {Zarafa.core.data.SharedComponentType} type Type of component a context can bid for.
     * @param {Ext.data.Record} record Optionally passed record.
     * @return {Ext.Component} Component
     */
    getSharedComponent: function (type, record) {
        var component;
        switch (type) {
            case Zarafa.core.data.SharedComponentType['plugins.calendarimporter.dialogs.importevents']:
                component = Zarafa.plugins.calendarimporter.dialogs.ImportContentPanel;
                break;
            case Zarafa.core.data.SharedComponentType['plugins.calendarimporter.settings.dialogs.calsyncedit']:
                component = Zarafa.plugins.calendarimporter.settings.dialogs.CalSyncEditContentPanel;
                break;
            case Zarafa.core.data.SharedComponentType['common.contextmenu']:
                component = Zarafa.plugins.calendarimporter.ui.ContextMenu;
                break;
        }

        return component;
    }
});


/*############################################################################################################################*
 * STARTUP 
 *############################################################################################################################*/
Zarafa.onReady(function () {
    container.registerPlugin(new Zarafa.core.PluginMetaData({
        name: 'calendarimporter',
        displayName: dgettext('plugin_calendarimporter', 'Calendarimporter Plugin'),
        about: Zarafa.plugins.calendarimporter.ABOUT,
        pluginConstructor: Zarafa.plugins.calendarimporter.ImportPlugin
    }));
});
/**
 * SettingsCalSyncWidget.js, Kopano calender to ics im/exporter
 *
 * Author: Christoph Haas <christoph.h@sprinternet.at>
 * Copyright (C) 2012-2018 Christoph Haas
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

Ext.namespace('Zarafa.plugins.calendarimporter.settings');

/**
 * @class Zarafa.plugins.calendarimporter.settings.SettingsCalSyncWidget
 * @extends Zarafa.settings.ui.SettingsWidget
 * @xtype calendarimporter.settingscalsyncwidget
 *
 */
Zarafa.plugins.calendarimporter.settings.SettingsCalSyncWidget = Ext.extend(Zarafa.settings.ui.SettingsWidget, {
    /**
     * @cfg {Zarafa.settings.SettingsContext} settingsContext
     */
    settingsContext: undefined,

    /**
     * @constructor
     * @param {Object} config Configuration object
     */
    constructor: function (config) {
        config = config || {};

        var store = new Ext.data.JsonStore({
            fields: [
                {name: 'id', type: 'int'},
                {name: 'icsurl'},
                {name: 'user'},
                {name: 'pass'},
                {name: 'intervall', type: 'int'},
                {name: 'calendar'},
                {name: 'calendarname'},
                {name: 'lastsync'}
            ],
            sortInfo: {
                field: 'id',
                direction: 'ASC'
            },
            autoDestroy: true
        });

        Ext.applyIf(config, {
            height: 400,
            title: dgettext('plugin_calendarimporter', 'Calendar Sync settings'),
            xtype: 'calendarimporter.settingscalsyncwidget',
            layout: {
                // override from SettingsWidget
                type: 'fit'
            },
            items: [{
                xtype: 'calendarimporter.calsyncpanel',
                store: store,
                ref: 'calsyncPanel'
            }]
        });

        Zarafa.plugins.calendarimporter.settings.SettingsCalSyncWidget.superclass.constructor.call(this, config);
    },

    /**
     * Called by the {@link Zarafa.settings.ui.SettingsCategory Category} when
     * it has been called with {@link zarafa.settings.ui.SettingsCategory#update}.
     * This is used to load the latest version of the settings from the
     * {@link Zarafa.settings.SettingsModel} into the UI of this category.
     * @param {Zarafa.settings.SettingsModel} settingsModel The settings to load
     */
    update: function (settingsModel) {
        this.model = settingsModel;

        // Convert the signatures into Store data
        var icslinks = settingsModel.get('zarafa/v1/contexts/calendar/icssync', true);
        var syncArray = [];
        for (var key in icslinks) {
            if (icslinks.hasOwnProperty(key)) { // skip inherited props
                syncArray.push(Ext.apply({}, icslinks[key], {id: key}));
            }
        }

        // Load all icslinks into the GridPanel
        var store = this.calsyncPanel.calsyncGrid.getStore();
        store.loadData(syncArray);
    },

    /**
     * Called by the {@link Zarafa.settings.ui.SettingsCategory Category} when
     * it has been called with {@link zarafa.settings.ui.SettingsCategory#updateSettings}.
     * This is used to update the settings from the UI into the {@link Zarafa.settings.SettingsModel settings model}.
     * @param {Zarafa.settings.SettingsModel} settingsModel The settings to update
     */
    updateSettings: function (settingsModel) {
        settingsModel.beginEdit();

        // Start reading the Grid store and convert the contents back into
        // an object which can be pushed to the settings.
        var icslinks = this.calsyncPanel.calsyncGrid.getStore().getRange();
        var icslinkData = {};
        for (var i = 0, len = icslinks.length; i < len; i++) {
            var icslink = icslinks[i];

            icslinkData[icslink.get('id')] = {
                'icsurl': icslink.get('icsurl'),
                'intervall': icslink.get('intervall'),
                'user': icslink.get('user'),
                'pass': icslink.get('pass'),
                'lastsync': icslink.get('lastsync'),
                'calendar': icslink.get('calendar'),
                'calendarname': Zarafa.plugins.calendarimporter.data.Actions.getCalendarFolderByEntryid(icslink.get('calendar')).display_name
            };
        }
        settingsModel.set('zarafa/v1/contexts/calendar/icssync', icslinkData);

        settingsModel.endEdit();
    }
});

Ext.reg('calendarimporter.settingscalsyncwidget', Zarafa.plugins.calendarimporter.settings.SettingsCalSyncWidget);/**
 * SettingsWidget.js, Kopano calender to ics im/exporter
 *
 * Author: Christoph Haas <christoph.h@sprinternet.at>
 * Copyright (C) 2012-2018 Christoph Haas
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

Ext.namespace('Zarafa.plugins.calendarimporter.settings');

/**
 * @class Zarafa.plugins.calendarimporter.settings.SettingsWidget
 * @extends Zarafa.settings.ui.SettingsWidget
 * @xtype calendarimporter.settingswidget
 *
 */
Zarafa.plugins.calendarimporter.settings.SettingsWidget = Ext.extend(Zarafa.settings.ui.SettingsWidget, {
    /**
     * @cfg {Zarafa.settings.SettingsContext} settingsContext
     */
    settingsContext: undefined,

    /**
     * @constructor
     * @param {Object} config Configuration object
     */
    constructor: function (config) {
        config = config || {};

        Ext.applyIf(config, {
            title: dgettext('plugin_calendarimporter', 'Calendar Import/Export plugin settings'),
            xtype: 'calendarimporter.settingswidget',
            items: [
                {
                    xtype: 'checkbox',
                    name: 'zarafa/v1/plugins/calendarimporter/enable_sync',
                    ref: 'enableSync',
                    fieldLabel: dgettext('plugin_calendarimporter', 'Enable ical sync'),
                    lazyInit: false
                },
                this.createSelectBox(),
                this.createTimezoneBox()
            ]
        });

        Zarafa.plugins.calendarimporter.settings.SettingsWidget.superclass.constructor.call(this, config);
    },

    createSelectBox: function () {
        var myStore = Zarafa.plugins.calendarimporter.data.Actions.getAllCalendarFolders(true);

        return {
            xtype: "selectbox",
            ref: 'defaultCalendar',
            editable: false,
            name: "zarafa/v1/plugins/calendarimporter/default_calendar",
            value: Zarafa.plugins.calendarimporter.data.Actions.getCalendarFolderByName(container.getSettingsModel().get("zarafa/v1/plugins/calendarimporter/default_calendar")).entryid,
            width: 100,
            fieldLabel: dgettext('plugin_calendarimporter', 'Default calender'),
            store: myStore,
            mode: 'local',
            labelSeperator: ":",
            border: false,
            anchor: "100%",
            scope: this,
            allowBlank: false
        }
    },

    createTimezoneBox: function () {
        return {
            xtype: "selectbox",
            ref: 'defaultTimezone',
            editable: false,
            name: "zarafa/v1/plugins/calendarimporter/default_timezone",
            value: Zarafa.plugins.calendarimporter.data.Timezones.unMap(container.getSettingsModel().get("zarafa/v1/plugins/calendarimporter/default_timezone")),
            width: 100,
            fieldLabel: dgettext('plugin_calendarimporter', 'Default timezone'),
            store: Zarafa.plugins.calendarimporter.data.Timezones.store,
            labelSeperator: ":",
            mode: 'local',
            border: false,
            anchor: "100%",
            scope: this,
            allowBlank: false
        }
    },

    /**
     * Called by the {@link Zarafa.settings.ui.SettingsCategory Category} when
     * it has been called with {@link zarafa.settings.ui.SettingsCategory#update}.
     * This is used to load the latest version of the settings from the
     * {@link Zarafa.settings.SettingsModel} into the UI of this category.
     * @param {Zarafa.settings.SettingsModel} settingsModel The settings to load
     */
    update: function (settingsModel) {
        this.enableSync.setValue(settingsModel.get(this.enableSync.name));
        this.defaultCalendar.setValue(Zarafa.plugins.calendarimporter.data.Actions.getCalendarFolderByName(settingsModel.get(this.defaultCalendar.name)).entryid);
        this.defaultTimezone.setValue(settingsModel.get(this.defaultTimezone.name));
    },

    /**
     * Called by the {@link Zarafa.settings.ui.SettingsCategory Category} when
     * it has been called with {@link zarafa.settings.ui.SettingsCategory#updateSettings}.
     * This is used to update the settings from the UI into the {@link Zarafa.settings.SettingsModel settings model}.
     * @param {Zarafa.settings.SettingsModel} settingsModel The settings to update
     */
    updateSettings: function (settingsModel) {
        // check if the user changed a value
        var changed = false;

        if (settingsModel.get(this.enableSync.name) != this.enableSync.getValue()) {
            changed = true;
        } else if (settingsModel.get(this.defaultCalendar.name) != Zarafa.plugins.calendarimporter.data.Actions.getCalendarFolderByEntryid(this.defaultCalendar.getValue()).display_name) {
            changed = true;
        } else if (settingsModel.get(this.defaultTimezone.name) != this.defaultTimezone.getValue()) {
            changed = true;
        }

        if (changed) {
            // Really save changes
            settingsModel.set(this.enableSync.name, this.enableSync.getValue());
            settingsModel.set(this.defaultCalendar.name, Zarafa.plugins.calendarimporter.data.Actions.getCalendarFolderByEntryid(this.defaultCalendar.getValue()).display_name); // store name
            settingsModel.set(this.defaultTimezone.name, this.defaultTimezone.getValue());

            this.onUpdateSettings();
        }
    },

    /**
     * Called after the {@link Zarafa.settings.SettingsModel} fires the {@link Zarafa.settings.SettingsModel#save save}
     * event to indicate the settings were successfully saved and it will forcefully realod the webapp.
     * settings which were saved to the server.
     * @private
     */
    onUpdateSettings: function () {
        var message = _('Your WebApp needs to be reloaded to make the changes visible!');
        message += '<br/><br/>';
        message += _('WebApp will automatically restart in order for these changes to take effect');
        message += '<br/>';

        Zarafa.common.dialogs.MessageBox.addCustomButtons({
            title: _('Restart WebApp'),
            msg: message,
            icon: Ext.MessageBox.QUESTION,
            fn: this.restartWebapp,
            customButton: [{
                text: _('Restart'),
                name: 'restart'
            }, {
                text: _('Cancel'),
                name: 'cancel'
            }],
            scope: this
        });

    },

    /**
     * Event handler for {@link #onResetSettings}. This will check if the user
     * wishes to reset the default settings or not.
     * @param {String} button The button which user pressed.
     * @private
     */
    restartWebapp: function (button) {
        if (button === 'restart') {
            var contextModel = this.ownerCt.settingsContext.getModel();
            var realModel = contextModel.getRealSettingsModel();

            realModel.save();

            this.loadMask = new Zarafa.common.ui.LoadMask(Ext.getBody(), {
                msg: '<b>' + _('Webapp is reloading, Please wait.') + '</b>'
            });
            this.loadMask.show();

            this.mon(realModel, 'save', this.onSettingsSave, this);
            this.mon(realModel, 'exception', this.onSettingsException, this);
        }

    },

    /**
     * Called when the {@link Zarafa.settings.} fires the {@link Zarafa.settings.SettingsModel#save save}
     * event to indicate the settings were successfully saved and it will forcefully realod the webapp.
     * @param {Zarafa.settings.SettingsModel} model The model which fired the event.
     * @param {Object} parameters The key-value object containing the action and the corresponding
     * settings which were saved to the server.
     * @private
     */
    onSettingsSave: function (model, parameters) {
        this.mun(model, 'save', this.onSettingsSave, this);
        Zarafa.core.Util.reloadWebapp();
    },

    /**
     * Called when the {@link Zarafa.settings.SettingsModel} fires the {@link Zarafa.settings.SettingsModel#exception exception}
     * event to indicate the settings were not successfully saved.
     * @param {Zarafa.settings.SettingsModel} model The settings model which fired the event
     * @param {String} type The value of this parameter will be either 'response' or 'remote'.
     * @param {String} action Name of the action (see {@link Ext.data.Api#actions}).
     * @param {Object} options The object containing a 'path' and 'value' field indicating
     * respectively the Setting and corresponding value for the setting which was being saved.
     * @param {Object} response The response object as received from the PHP-side
     * @private
     */
    onSettingsException: function (model, type, action, options, response) {
        this.loadMask.hide();

        // Remove event handlers
        this.mun(model, 'save', this.onSettingsSave, this);
        this.mun(model, 'exception', this.onSettingsException, this);
    }
});

Ext.reg('calendarimporter.settingswidget', Zarafa.plugins.calendarimporter.settings.SettingsWidget);
/**
 * CalSyncEditContentPanel.js, Kopano calender to ics im/exporter
 *
 * Author: Christoph Haas <christoph.h@sprinternet.at>
 * Copyright (C) 2012-2018 Christoph Haas
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

Ext.namespace('Zarafa.plugins.calendarimporter.settings.dialogs');

/**
 * @class Zarafa.plugins.calendarimporter.settings.dialogs.CalSyncEditContentPanel
 * @extends Zarafa.core.ui.ContentPanel
 * @xtype calendarimporter.calsynceditcontentpanel
 *
 * {@link Zarafa.plugins.calendarimporter.settings.dialogs.CalSyncEditContentPanel CalSyncEditContentPanel} will be used to edit ics sync entries.
 */
Zarafa.plugins.calendarimporter.settings.dialogs.CalSyncEditContentPanel = Ext.extend(Zarafa.core.ui.ContentPanel, {
    /**
     * @constructor
     * @param config Configuration structure
     */
    constructor: function (config) {
        config = config || {};

        // Add in some standard configuration data.
        Ext.applyIf(config, {
            // Override from Ext.Component
            xtype: 'calendarimporter.calsynceditcontentpanel',
            layout: 'fit',
            model: true,
            autoSave: false,
            width: 400,
            height: 400,
            title: dgettext('plugin_calendarimporter', 'ICAL Sync'),
            items: [{
                xtype: 'calendarimporter.calsynceditpanel',
                item: config.item
            }]
        });

        Zarafa.plugins.calendarimporter.settings.dialogs.CalSyncEditContentPanel.superclass.constructor.call(this, config);
    }
});

Ext.reg('calendarimporter.calsynceditcontentpanel', Zarafa.plugins.calendarimporter.settings.dialogs.CalSyncEditContentPanel);
/**
 * CalSyncEditPanel.js, Kopano calender to ics im/exporter
 *
 * Author: Christoph Haas <christoph.h@sprinternet.at>
 * Copyright (C) 2012-2018 Christoph Haas
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

Ext.namespace('Zarafa.plugins.calendarimporter.settings.dialogs');

/**
 * @class Zarafa.plugins.calendarimporter.settings.dialogs.CalSyncEditPanel
 * @extends Ext.form.FormPanel
 * @xtype calendarimporter.calsynceditpanel
 *
 * Will generate UI for {@link Zarafa.plugins.calendarimporter.settings.dialogs.CalSyncEditPanel CalSyncEditPanel}.
 */
Zarafa.plugins.calendarimporter.settings.dialogs.CalSyncEditPanel = Ext.extend(Ext.form.FormPanel, {

    /**
     * the id of the currently edited item
     */
    currentItem: undefined,

    /**
     * @constructor
     * @param config Configuration structure
     */
    constructor: function (config) {
        config = config || {};

        if (config.item)
            this.currentItem = config.item;

        Ext.applyIf(config, {
            // Override from Ext.Component
            xtype: 'calendarimporter.calsynceditpanel',
            labelAlign: 'top',
            defaultType: 'textfield',
            items: this.createPanelItems(config),
            buttons: [{
                text: _('Save'),
                handler: this.doSave,
                scope: this
            },
                {
                    text: _('Cancel'),
                    handler: this.doClose,
                    scope: this
                }]
        });

        Zarafa.plugins.calendarimporter.settings.dialogs.CalSyncEditPanel.superclass.constructor.call(this, config);
    },

    /**
     * close the dialog
     */
    doClose: function () {
        this.dialog.close();
    },

    /**
     * save the data to the store
     */
    doSave: function () {
        var store = this.dialog.store;
        var id = 0;
        var record = undefined;

        if (!this.currentItem) {
            record = new store.recordType({
                id: this.hashCode(this.icsurl.getValue()),
                icsurl: this.icsurl.getValue(),
                intervall: this.intervall.getValue(),
                user: this.user.getValue(),
                pass: Ext.util.base64.encode(this.pass.getValue()),
                calendar: this.calendar.getValue(),
                calendarname: Zarafa.plugins.calendarimporter.data.Actions.getCalendarFolderByEntryid(this.calendar.getValue()).display_name,
                lastsync: "never"
            });
        }

        if (this.icsurl.isValid()) {
            if (record) {
                store.add(record);
            } else {
                this.currentItem.set('icsurl', this.icsurl.getValue());
                this.currentItem.set('intervall', this.intervall.getValue());
                this.currentItem.set('user', this.user.getValue());
                this.currentItem.set('pass', Ext.util.base64.encode(this.pass.getValue()));
                this.currentItem.set('calendar', this.calendar.getValue());
                this.currentItem.set('calendarname', Zarafa.plugins.calendarimporter.data.Actions.getCalendarFolderByEntryid(this.calendar.getValue()).display_name);
            }
            this.dialog.close();
        }
    },

    /**
     * Function will create panel items for {@link Zarafa.plugins.calendarimporter.settings.dialogs.CalSyncEditPanel CalSyncEditPanel}
     * @return {Array} array of items that should be added to panel.
     * @private
     */
    createPanelItems: function (config) {
        var icsurl = "";
        var intervall = "15";
        var user = "";
        var pass = "";
        var calendarname = "";
        var calendar = Zarafa.plugins.calendarimporter.data.Actions.getCalendarFolderByName(container.getSettingsModel().get("zarafa/v1/plugins/calendarimporter/default_calendar")).entryid;
        var myStore = Zarafa.plugins.calendarimporter.data.Actions.getAllCalendarFolders(true);

        if (config.item) {
            icsurl = config.item.get('icsurl');
            intervall = config.item.get('intervall');
            user = config.item.get('user');
            pass = Ext.util.base64.decode(config.item.get('pass'));
            calendar = config.item.get('calendar');
            calendarname = config.item.get('calendarname');
        }


        return [{
            xtype: 'fieldset',
            title: dgettext('plugin_calendarimporter', 'ICAL Information'),
            defaultType: 'textfield',
            layout: 'form',
            flex: 1,
            defaults: {
                anchor: '100%',
                flex: 1
            },
            items: [{
                fieldLabel: dgettext('plugin_calendarimporter', 'ICS Url'),
                name: 'icsurl',
                ref: '../icsurl',
                value: icsurl,
                allowBlank: false
            },
                {
                    xtype: 'selectbox',
                    fieldLabel: dgettext('plugin_calendarimporter', 'Destination Calendar'),
                    name: 'calendar',
                    ref: '../calendar',
                    value: calendar,
                    editable: false,
                    store: myStore,
                    mode: 'local',
                    labelSeperator: ":",
                    border: false,
                    anchor: "100%",
                    scope: this,
                    allowBlank: false
                },
                {
                    xtype: 'numberfield',
                    fieldLabel: dgettext('plugin_calendarimporter', 'Sync Intervall (minutes)'),
                    name: 'intervall',
                    ref: '../intervall',
                    value: intervall,
                    allowBlank: false
                }]
        },
            {
                xtype: 'fieldset',
                title: dgettext('plugin_calendarimporter', 'Authentication (optional)'),
                defaultType: 'textfield',
                layout: 'form',
                defaults: {
                    anchor: '100%'
                },
                items: [{
                    fieldLabel: dgettext('plugin_calendarimporter', 'Username'),
                    name: 'user',
                    ref: '../user',
                    value: user,
                    allowBlank: true
                },
                    {
                        fieldLabel: dgettext('plugin_calendarimporter', 'Password'),
                        name: 'pass',
                        ref: '../pass',
                        value: pass,
                        inputType: 'password',
                        allowBlank: true
                    }]
            }];
    },

    /**
     * Java String.hashCode() implementation
     * @private
     */
    hashCode: function (str) {
        var hash = 0;
        var chr = 0;
        var i = 0;

        if (str.length == 0) return hash;
        for (i = 0; i < str.length; i++) {
            chr = str.charCodeAt(i);
            hash = ((hash << 5) - hash) + chr;
            hash = hash & hash; // Convert to 32bit integer
        }
        return Math.abs(hash);
    }
});

Ext.reg('calendarimporter.calsynceditpanel', Zarafa.plugins.calendarimporter.settings.dialogs.CalSyncEditPanel);
/**
 * CalSyncGrid.js, Kopano calender to ics im/exporter
 *
 * Author: Christoph Haas <christoph.h@sprinternet.at>
 * Copyright (C) 2012-2018 Christoph Haas
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

Ext.namespace('Zarafa.plugins.calendarimporter.settings.ui');

/**
 * @class Zarafa.plugins.calendarimporter.settings.ui.CalSyncGrid
 * @extends Ext.grid.GridPanel
 * @xtype calendarimporter.calsyncgrid
 *
 */
Zarafa.plugins.calendarimporter.settings.ui.CalSyncGrid = Ext.extend(Ext.grid.GridPanel, {
    /**
     * @constructor
     * @param {Object} config Configuration structure
     */
    constructor: function (config) {
        config = config || {};

        Ext.applyIf(config, {
            xtype: 'calendarimporter.calsyncgrid',
            border: true,
            store: config.store,
            viewConfig: {
                forceFit: true,
                emptyText: '<div class=\'emptytext\'>' + dgettext('plugin_calendarimporter', 'No ICAL sync entry exists') + '</div>'
            },
            loadMask: this.initLoadMask(),
            columns: this.initColumnModel(),
            selModel: this.initSelectionModel(),
            listeners: {
                viewready: this.onViewReady,
                rowdblclick: this.onRowDblClick,
                scope: this
            }
        });

        Zarafa.plugins.calendarimporter.settings.ui.CalSyncGrid.superclass.constructor.call(this, config);
    },

    /**
     * initialize events for the grid panel.
     * @private
     */
    initEvents: function () {
        Zarafa.plugins.calendarimporter.settings.ui.CalSyncGrid.superclass.initEvents.call(this);

        // select first icssync when store has finished loading
        this.mon(this.store, 'load', this.onViewReady, this, {single: true});
    },

    /**
     * Render function
     * @return {String}
     * @private
     */
    renderAuthColumn: function (value, p, record) {
        return value ? "true" : "false";
    },

    /**
     * Render function
     * @return {String}
     * @private
     */
    renderCalendarColumn: function (value, p, record) {
        return Zarafa.plugins.calendarimporter.data.Actions.getCalendarFolderByEntryid(value).display_name;
    },

    /**
     * Creates a column model object, used in {@link #colModel} config
     * @return {Ext.grid.ColumnModel} column model object
     * @private
     */
    initColumnModel: function () {
        return [{
            dataIndex: 'icsurl',
            header: dgettext('plugin_calendarimporter', 'ICS File'),
            renderer: Zarafa.common.ui.grid.Renderers.text
        },
            {
                dataIndex: 'calendarname',
                header: dgettext('plugin_calendarimporter', 'Destination Calender'),
                renderer: Zarafa.common.ui.grid.Renderers.text
            },
            {
                dataIndex: 'user',
                header: dgettext('plugin_calendarimporter', 'Authentication'),
                renderer: this.renderAuthColumn
            },
            {
                dataIndex: 'intervall',
                header: dgettext('plugin_calendarimporter', 'Sync Intervall')
            },
            {
                dataIndex: 'lastsync',
                header: dgettext('plugin_calendarimporter', 'Last Synchronisation'),
                renderer: Zarafa.common.ui.grid.Renderers.text
            }]
    },

    /**
     * Creates a selection model object, used in {@link #selModel} config
     * @return {Ext.grid.RowSelectionModel} selection model object
     * @private
     */
    initSelectionModel: function () {
        return new Ext.grid.RowSelectionModel({
            singleSelect: true
        });
    },

    /**
     * Initialize the {@link Ext.grid.GridPanel.loadMask} field
     *
     * @return {Ext.LoadMask} The configuration object for {@link Ext.LoadMask}
     * @private
     */
    initLoadMask: function () {
        return {
            msg: dgettext('plugin_calendarimporter', 'Loading ics sync entries...')
        };
    },

    /**
     * Event handler which is fired when the gridPanel is ready. This will automatically
     * select the first row in the grid.
     * @private
     */
    onViewReady: function () {
        this.getSelectionModel().selectFirstRow();
    },

    /**
     * Function will be called to remove a ics sync entry.
     */
    removeIcsSyncAs: function () {
        var icsRecord = this.getSelectionModel().getSelected();
        if (!icsRecord) {
            Ext.Msg.alert(dgettext('plugin_calendarimporter', 'Alert'), dgettext('plugin_calendarimporter', 'Please select a ics sync entry.'));
            return;
        }

        this.store.remove(icsRecord);
    },

    /**
     * Event handler which is fired when the {@link Zarafa.plugins.calendarimporter.settings.ui.CalSyncGrid CalSyncGrid} is double clicked.
     * it will call generic function to handle the functionality.
     * @private
     */
    onRowDblClick: function (grid, rowIndex) {
        Zarafa.core.data.UIFactory.openLayerComponent(Zarafa.core.data.SharedComponentType['plugins.calendarimporter.settings.dialogs.calsyncedit'], undefined, {
            store: grid.getStore(),
            item: grid.getStore().getAt(rowIndex),
            manager: Ext.WindowMgr
        });
    }
});

Ext.reg('calendarimporter.calsyncgrid', Zarafa.plugins.calendarimporter.settings.ui.CalSyncGrid);
/**
 * CalSyncPanel.js, Kopano calender to ics im/exporter
 *
 * Author: Christoph Haas <christoph.h@sprinternet.at>
 * Copyright (C) 2012-2018 Christoph Haas
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

Ext.namespace('Zarafa.plugins.calendarimporter.settings.ui');

/**
 * @class Zarafa.plugins.calendarimporter.settings.ui.CalSyncPanel
 * @extends Ext.Panel
 * @xtype calendarimporter.calsyncpanel
 * Will generate UI for the {@link Zarafa.common.settings.SettingsSendAsWidget SettingsSendAsWidget}.
 */
Zarafa.plugins.calendarimporter.settings.ui.CalSyncPanel = Ext.extend(Ext.Panel, {

    // store
    store: undefined,

    /**
     * @constructor
     * @param config Configuration structure
     */
    constructor: function (config) {
        config = config || {};
        if (config.store)
            this.store = config.store;

        Ext.applyIf(config, {
            // Override from Ext.Component
            xtype: 'calendarimporter.calsyncpanel',
            border: false,
            layout: {
                type: 'vbox',
                align: 'stretch',
                pack: 'start'
            },
            items: this.createPanelItems(this.store)
        });

        Zarafa.plugins.calendarimporter.settings.ui.CalSyncPanel.superclass.constructor.call(this, config);
    },

    /**
     * Function will create panel items for {@link Zarafa.plugins.calendarimporter.settings.ui.CalSyncPanel CalSyncPanel}
     * @return {Array} array of items that should be added to panel.
     * @private
     */
    createPanelItems: function (store) {
        return [{
            xtype: 'displayfield',
            value: dgettext('plugin_calendarimporter', 'Setup calendars you want to subscribe to.'),
            fieldClass: 'x-form-display-field'
        }, {
            xtype: 'container',
            flex: 1,
            layout: {
                type: 'hbox',
                align: 'stretch',
                pack: 'start'
            },
            items: [{
                xtype: 'calendarimporter.calsyncgrid',
                ref: '../calsyncGrid',
                store: store,
                flex: 1
            }, {
                xtype: 'container',
                width: 160,
                defaults: {
                    width: 140
                },
                layout: {
                    type: 'vbox',
                    align: 'center',
                    pack: 'start'
                },
                items: [{
                    xtype: 'button',
                    text: _('Add') + '...',
                    handler: this.onCalSyncAdd,
                    ref: '../../addButton',
                    scope: this
                }, {
                    xtype: 'spacer',
                    height: 20
                }, {
                    xtype: 'button',
                    text: _('Remove') + '...',
                    disabled: true,
                    ref: '../../removeButton',
                    handler: this.onCalSyncRemove,
                    scope: this
                }]
            }]
        }];
    },

    /**
     * initialize events for the panel.
     * @private
     */
    initEvents: function () {
        Zarafa.plugins.calendarimporter.settings.ui.CalSyncPanel.superclass.initEvents.call(this);

        // register event to enable/disable buttons
        this.mon(this.calsyncGrid.getSelectionModel(), 'selectionchange', this.onGridSelectionChange, this);
    },

    /**
     * Handler function will be called when user clicks on 'Add' button.
     * @private
     */
    onCalSyncAdd: function () {
        Zarafa.core.data.UIFactory.openLayerComponent(Zarafa.core.data.SharedComponentType['plugins.calendarimporter.settings.dialogs.calsyncedit'], undefined, {
            store: this.store,
            item: undefined,
            manager: Ext.WindowMgr
        });
    },

    /**
     * Event handler will be called when selection in {@link Zarafa.plugins.calendarimporter.settings.ui.CalSyncGrid CalSyncGrid}
     * has been changed
     * @param {Ext.grid.RowSelectionModel} selectionModel selection model that fired the event
     */
    onGridSelectionChange: function (selectionModel) {
        var noSelection = (selectionModel.hasSelection() === false);

        this.removeButton.setDisabled(noSelection);
    },

    /**
     * Handler function will be called when user clicks on 'Remove' button.
     * @private
     */
    onCalSyncRemove: function () {
        this.calsyncGrid.removeIcsSyncAs();
    },

    /**
     * Function will be used to reload data in the store.
     */
    discardChanges: function () {
        this.store.load();
    },

    /**
     * Function will be used to save changes in the store.
     */
    saveChanges: function () {
        this.store.save();
    }
});

Ext.reg('calendarimporter.calsyncpanel', Zarafa.plugins.calendarimporter.settings.ui.CalSyncPanel);
/**
 * ContectMenu.js, Kopano calender to ics im/exporter
 *
 * Author: Christoph Haas <christoph.h@sprinternet.at>
 * Copyright (C) 2012-2018 Christoph Haas
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

Ext.namespace('Zarafa.plugins.calendarimporter.ui');

/**
 * @class Zarafa.plugins.calendarimporter.ui.ContextMenu
 * @extends Zarafa.hierarchy.ui.ContextMenu
 * @xtype calendarimporter.hierarchycontextmenu
 */
Zarafa.plugins.calendarimporter.ui.ContextMenu = Ext.extend(Zarafa.hierarchy.ui.ContextMenu, {

    /**
     * @constructor
     * @param {Object} config Configuration object
     */
    constructor: function (config) {
        config = config || {};

        if (config.contextNode) {
            config.contextTree = config.contextNode.getOwnerTree();
        }

        Zarafa.plugins.calendarimporter.ui.ContextMenu.superclass.constructor.call(this, config);

        // add item to menu
        var additionalItems = this.createAdditionalContextMenuItems(config);
        for (var i = 0; i < additionalItems.length; i++) {
            config.items[0].push(additionalItems[i]);
        }

        Zarafa.plugins.calendarimporter.ui.ContextMenu.superclass.constructor.call(this, config); // redo ... otherwise menu does not get published
    },

    /**
     * Create the Action context menu items.
     * @param {Object} config Configuration object for the {@link Zarafa.plugins.calendarimporter.ui.ContextMenu ContextMenu}
     * @return {Zarafa.core.ui.menu.ConditionalItem|Array} The list of Action context menu items
     * @private
     *
     * Note: All handlers are called within the scope of {@link Zarafa.plugins.calendarimporter.ui.ContextMenu HierarchyContextMenu}
     */
    createAdditionalContextMenuItems: function (config) {
        return [{
            xtype: 'menuseparator'
        }, {
            text: dgettext('plugin_calendarimporter', 'Import Calendar'),
            iconCls: 'icon_calendarimporter_import',
            handler: this.onContextItemImport,
            beforeShow: function (item, record) {
                var access = record.get('access') & Zarafa.core.mapi.Access.ACCESS_MODIFY;
                if (!access || (record.isIPMSubTree() && !record.getMAPIStore().isDefaultStore())) {
                    item.setDisabled(true);
                } else {
                    item.setDisabled(false);
                }
            }
        }, {
            text: dgettext('plugin_calendarimporter', 'Export Calendar'),
            iconCls: 'icon_calendarimporter_export',
            handler: this.onContextItemExport,
            beforeShow: function (item, record) {
                var access = record.get('access') & Zarafa.core.mapi.Access.ACCESS_READ;
                if (!access || (record.isIPMSubTree() && !record.getMAPIStore().isDefaultStore())) {
                    item.setDisabled(true);
                } else {
                    item.setDisabled(false);
                }
            }
        }];
    },

    /**
     * Fires on selecting 'Open' menu option from {@link Zarafa.plugins.calendarimporter.ui.ContextMenu ContextMenu}
     * @private
     */
    onContextItemExport: function () {
        Zarafa.plugins.calendarimporter.data.Actions.exportToICS(this.records.get("store_entryid"), undefined, this.records);
    },

    /**
     * Fires on selecting 'Open' menu option from {@link Zarafa.plugins.calendarimporter.ui.ContextMenu ContextMenu}
     * @private
     */
    onContextItemImport: function () {
        var componentType = Zarafa.core.data.SharedComponentType['plugins.calendarimporter.dialogs.importevents'];
        var config = {
            modal: true,
            folder: this.records.get("entryid")
        };

        Zarafa.core.data.UIFactory.openLayerComponent(componentType, undefined, config);
    }
});

Ext.reg('calendarimporter.hierarchycontextmenu', Zarafa.plugins.calendarimporter.ui.ContextMenu);